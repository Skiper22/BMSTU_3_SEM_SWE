#ifndef _CHECK_MEMORY_H
#define _CHECK_MEMORY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int tests_allocate_and_free_malloc_string(void);
int tests_allocate_and_free_malloc_structs(void);

#endif //_CHECK_MEMORY_H

