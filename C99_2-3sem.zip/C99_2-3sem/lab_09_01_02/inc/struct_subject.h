#ifndef _STRUCT_SUBJECT_H
#define _STRUCT_SUBJECT_H

typedef struct st_subject
{
    char *name_subject;
    double weight;
    double volume;
} subject_t;

#endif //_STRUCT_SUBJECT_H

