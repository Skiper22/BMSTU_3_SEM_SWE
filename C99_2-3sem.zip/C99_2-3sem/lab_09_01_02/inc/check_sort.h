#ifndef _CHECK_SORT_H
#define _CHECK_SORT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int test_sort_array_by_density(void);

#endif //_CHECK_SORT_H

