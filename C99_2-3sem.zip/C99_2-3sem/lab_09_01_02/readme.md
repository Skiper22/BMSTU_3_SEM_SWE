* [C](https://ru.wikipedia.org/wiki/%D0%A1%D0%B8_(%D1%8F%D0%B7%D1%8B%D0%BA_%D0%BF%D1%80%D0%BE%D0%B3%D1%80%D0%B0%D0%BC%D0%BC%D0%B8%D1%80%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F))
* [Moodle ИУ7](http://e-learning.bmstu.ru/portal_iu7/course/view.php?id=13)
* [Gitlab ИУ7](https://git.iu7.bmstu.ru)
