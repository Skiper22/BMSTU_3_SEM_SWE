#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>


#define MAX_LEN 256
#define MAX_LEN_WORD 16
#define MIN_REPEAT 1
#define RAISED 1
#define EMPTY 0
#define EQUAL 0

#define INPUT_SUCCESS 0
#define INPUT_ERROR 1
#define SIZE_OVERFLOW 2
#define OUTPUT_ERROR 3
#define SUCCESS_OUTPUT 0
#define SUCCESS 0
#define OK 0

int input_string(char *const str)
{
    char *p = fgets(str, MAX_LEN + 1, stdin);
    if ((p == NULL) || (str[strlen(str) - 1] != '\n') || (strlen(str) >= MAX_LEN))
        return INPUT_ERROR;
    size_t count_sym = 0;
    for (const char *pstr = str; *pstr != '\0'; ++pstr)
        if (ispunct(*pstr) || *pstr == ' ')
            ++count_sym;
    if (count_sym == strlen(str) - 1)
        return INPUT_ERROR;
    
    return INPUT_SUCCESS;
}

int get_array_words(char (*const arr_word)[MAX_LEN], size_t *count_words, char *const str)
{
    size_t j = 0, flag = 0;
    for (const char *pstr = str ; *pstr != '\0'; ++pstr)
    {
        if (*pstr == ' ' || ispunct(*pstr) || *pstr == '\n')
        {
            arr_word[*count_words][j] = '\0';
            if (strlen(arr_word[*count_words]) > MAX_LEN_WORD)
                return SIZE_OVERFLOW;
            if (flag)
                ++(*count_words);
            j = 0;
            flag = 0;
        }
        else if (*pstr != '\n')
        {
            arr_word[*count_words][j] = *pstr;
            j++;
            flag = 1;
        }
    }
    if (flag)
        ++(*count_words);
    
    return SUCCESS;
}
    
int get_array_uniq_words(char arr1_word[][MAX_LEN], const size_t *size1, char arr2_word[][MAX_LEN], const size_t *size2, char *const new_str)
{
    size_t count_output_words = 0;
    size_t flag = 1;
    for (size_t i = 0; i < *size1; i++)
    {
        size_t count_repeat = 0;    
        for (size_t j = 0; j < *size1; j++)
            if (strcmp(arr1_word[i], arr1_word[j]) == EQUAL)
                ++count_repeat;
        for (size_t k = 0; k < *size2; k++)
            if (strcmp(arr1_word[i], arr2_word[k]) == EQUAL)
                ++count_repeat;
        if (count_repeat == MIN_REPEAT)
            ++count_output_words;   
        if (flag == RAISED && count_output_words > 0)
            flag = 0;
        if (count_repeat == MIN_REPEAT)
        {
            strcat(new_str, " ");
            strcat(new_str, arr1_word[i]);
        }
    }
    
    for (size_t i = 0; i < *size2; i++)
    {
        size_t count_repeat = 0;    
        for (size_t j = 0; j < *size2; j++)
            if (strcmp(arr2_word[i], arr2_word[j]) == EQUAL)
                ++count_repeat;          
        for (size_t k = 0; k < *size1; k++)
            if (strcmp(arr2_word[i], arr1_word[k]) == EQUAL)
                ++count_repeat;
        if (count_repeat == MIN_REPEAT)
            ++count_output_words;   
        if (flag == RAISED && count_output_words > 0)
            flag = 0;
        if (count_repeat == MIN_REPEAT)
        {
            strcat(new_str, " ");
            strcat(new_str, arr2_word[i]);
        }
    }
    if (count_output_words == EMPTY)
        return OUTPUT_ERROR;
        
    return SUCCESS_OUTPUT;
}

void output_str(char *const new_str)
{
    printf("Result:%s", new_str);
}

int main()
{ 
    char str1[MAX_LEN] = "";
    char str2[MAX_LEN] = "";
    
    size_t size1 = 0;
    size_t size2 = 0;
    char arr1_word[MAX_LEN][MAX_LEN] = { "" };
    char arr2_word[MAX_LEN][MAX_LEN] = { "" };
    char new_str[MAX_LEN] = "";
    
    int rc = input_string(str1);
    if (rc != OK)
        return rc;
    rc = input_string(str2);
    if (rc != OK)
        return rc;
    rc = get_array_words(arr1_word, &size1, str1);
    if (rc != OK)
        return rc;
    rc = get_array_words(arr2_word, &size2, str2);
    if (rc != OK)
        return rc;
    rc = get_array_uniq_words(arr1_word, &size1, arr2_word, &size2, new_str);
    if (rc != OK)
        return rc;
    output_str(new_str);

    return EXIT_SUCCESS;
}
