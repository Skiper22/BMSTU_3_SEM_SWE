#ifndef MATRIX_H_

#define MATRIX_H_

typedef struct
{
    int **matrix;
    int n;
    int m;
} matrix_t;

#endif

