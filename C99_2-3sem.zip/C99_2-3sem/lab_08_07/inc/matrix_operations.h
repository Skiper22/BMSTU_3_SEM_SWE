#ifndef MATRIX_OPERATIONS_H_

#define MATRIX_OPERATIONS_H_

#include "matrix.h"

int cut_matrixes(matrix_t *m1, matrix_t *m2);
int even_matrixes(matrix_t *m1, matrix_t *m2);
int multiply_matrixes(matrix_t m1, matrix_t m2, matrix_t *m3);
int cut_matrix(matrix_t *matrix);
int cut_matrix_by_rows(matrix_t *matrix);
int cut_matrix_by_columns(matrix_t *matrix);
int find_row_with_min(matrix_t *matrix);
void shift_rows(matrix_t *matrix, int shift_i);
int change_matrix_to_square(matrix_t *matrix);
int find_column_with_min(matrix_t *matrix);
void shift_columns(matrix_t *matrix, int shift_i);
int expand_matrix(matrix_t *matrix, int size);
void copy_square_matrix(int **dst, int **src, int size);
void fill_rows(int **matrix, int old_size, int size);
void fill_columns(int  **matrix, int old_size, int size);
int get_mlt_of_column(int **matrix, const int count_cols, const int fix_num);
int get_max_of_row(int **matrix, const int fix_col, const int row_size);
int multiply_matrixes(matrix_t m1, matrix_t m2, matrix_t *m3);
void multiply(int **m1, int **m2, int **result, int size);

#endif

