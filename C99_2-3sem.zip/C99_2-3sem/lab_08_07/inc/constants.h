#ifndef CONSTANST_H_

#define CONSTANST_H_

#define SUCCESS 0
#define ERR_SIZES -1
#define ERR_ELEMENTS -2
#define ERR_MEMORY -3
#define ERR_POWER -4

#endif

