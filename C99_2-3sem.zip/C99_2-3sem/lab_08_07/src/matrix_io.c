#include <stdio.h>
#include <stdlib.h>
#include "constants.h"
#include "matrix.h"
#include "matrix_io.h"

int read_matrixes(matrix_t *m1, matrix_t*m2)
{
    int rc = scan_matrix(m1);
    if (rc == SUCCESS)
        rc = scan_matrix(m2);
    
    return rc;
}

int scan_matrix(matrix_t *matrix)
{
    int n = 0, m = 0;
    int rc = scanf("%d%d", &n, &m);
    if (rc == 2 && n > 0 && m > 0)
    {
        matrix->n = n;
        matrix->m = m;
        matrix->matrix = allocate_matrix(matrix->n, matrix->m);
        if (matrix->matrix)
            rc = scan_elements(matrix);
        else
            rc = ERR_MEMORY;
        if (rc != SUCCESS)
            free_matrix(matrix);
    }
    else
        rc = ERR_SIZES;
    
    return rc;
}

int scan_elements(matrix_t *matrix)
{
    int rc = SUCCESS, i = 0, j = 0;
    for (i = 0; i < matrix->n && rc == SUCCESS; i++)
    {
        rc = 1;
        for (j = 0; j < matrix->m && rc == 1; j++)
            rc = scanf("%d", &(matrix->matrix[i][j]));
        if (rc != 1)
            rc = ERR_ELEMENTS;
        else
            rc = SUCCESS;
    }
    
    return rc;
}

int **allocate_matrix(int n, int m)
{
    int **ptrs, *data;
    ptrs = malloc(n * sizeof(int *));
    data = calloc(n * m, sizeof(int));
    if (!data)
    {
        free(ptrs);
        ptrs = NULL;
    }
    if (ptrs != NULL)
    {
        for (int i = 0; i < n; i++)
            ptrs[i] = data + i * m;
    }
    
    return ptrs;
}

void free_matrix(matrix_t *matrix)
{
    matrix->n = 0;
    matrix->m = 0;
    if (matrix->matrix != NULL)
        free(matrix->matrix[0]);
    free(matrix->matrix);
    matrix->matrix = NULL;
}

void print_result(matrix_t matrix)
{
    for (int i = 0; i < matrix.n; i++)
    {
        for (int j = 0; j < matrix.m - 1; j++)
            printf("%d ", matrix.matrix[i][j]);
        printf("%d\n", matrix.matrix[i][matrix.m - 1]);
    }
}

void free_all_matrixes(matrix_t *m1, matrix_t *m2, matrix_t *m3)
{
    free_matrix(m1);
    free_matrix(m2);
    free_matrix(m3);
}

