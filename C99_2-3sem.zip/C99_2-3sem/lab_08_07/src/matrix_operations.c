#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>
#include "matrix.h"
#include "constants.h"
#include "matrix_io.h"
#include "matrix_operations.h"


int cut_matrixes(matrix_t *m1, matrix_t *m2)
{
    int rc = SUCCESS;
    rc = cut_matrix(m1);
    if (rc == SUCCESS)
        rc = cut_matrix(m2);
    
    return rc;
}

int cut_matrix(matrix_t *matrix)
{
    int rc = SUCCESS;
    if (matrix->n > matrix->m)
        rc = cut_matrix_by_rows(matrix);
    else if (matrix->n < matrix->m)
        rc = cut_matrix_by_columns(matrix);
    
    return rc;
}

int cut_matrix_by_rows(matrix_t *matrix)
{
    int rem_ind = 0;
    while (matrix->n != matrix->m)
    {
        rem_ind = find_row_with_min(matrix);
        shift_rows(matrix, rem_ind);
        matrix->n -= 1;
    }
    int rc = change_matrix_to_square(matrix);
    
    return rc;
}

int find_row_with_min(matrix_t *matrix)
{
    int row_num = 0;
    int min = matrix->matrix[0][0];
    for (int i = 0; i < matrix->m; i++)
        for (int j = 0; j < matrix->n; j++)
            if (matrix->matrix[j][i] < min)
            {
                min = matrix->matrix[j][i];
                row_num = j;
            }
    return row_num;
}

void shift_rows(matrix_t *matrix, int shift_i)
{
    for (int i = shift_i; i < matrix->n - 1; i++)
        for (int j = 0; j < matrix->m; j++)
            matrix->matrix[i][j] = matrix->matrix[i + 1][j];
    for (int j = 0; j < matrix->m; j++)
        matrix->matrix[matrix->n - 1][j] = 0;
}

int change_matrix_to_square(matrix_t *matrix)
{
    int rc = SUCCESS;
    int **square_matrix = allocate_matrix(matrix->n, matrix->m);
    if (square_matrix)
    {
        for (int i = 0; i < matrix->n; i++)
            for (int j = 0; j < matrix->m; j++)
                square_matrix[i][j] = matrix->matrix[i][j];
        free(matrix->matrix[0]);
        free(matrix->matrix);
        matrix->matrix = square_matrix;
    }
    else
        rc = ERR_MEMORY;
    
    return rc;
}

int cut_matrix_by_columns(matrix_t *matrix)
{
    int rem_ind = 0;
    while (matrix->n != matrix->m)
    {
        rem_ind = find_column_with_min(matrix);
        shift_columns(matrix, rem_ind);
        matrix->m--;
    }
    int rc = change_matrix_to_square(matrix);
    
    return rc;
}

int find_column_with_min(matrix_t *matrix)
{
    int column_num = 0;
    int min = matrix->matrix[0][0];
    for (int i = 0; i < matrix->m; i++)
        for (int j = 0; j < matrix->n; j++)
            if (matrix->matrix[j][i] < min)
            {
                min = matrix->matrix[j][i];
                column_num = i;
            }
    
    return column_num;
}

void shift_columns(matrix_t *matrix, int shift_i)
{
    for (int i = 0; i < matrix->n; i++)
        for (int j = shift_i; j < matrix->m - 1; j++)
            matrix->matrix[i][j] = matrix->matrix[i][j + 1];
    for (int i = 0; i < matrix->n; i++)
        matrix->matrix[i][matrix->m - 1] = 0;
}

int even_matrixes(matrix_t *m1, matrix_t *m2)
{
    int rc = SUCCESS;
    if (m1->n > m2->n)
        rc = expand_matrix(m2, m1->n);
    else if (m1->n < m2->m)
        rc = expand_matrix(m1, m2->n);
    return rc;
}

int expand_matrix(matrix_t *matrix, int size)
{
    int rc = SUCCESS;
    int **expanded_matrix = allocate_matrix(size, size);
    if (expanded_matrix)
    {
        copy_square_matrix(expanded_matrix, matrix->matrix, matrix->n);
        fill_rows(expanded_matrix, matrix->n, size);
        fill_columns(expanded_matrix, matrix->m, size);
        free(matrix->matrix[0]);
        free(matrix->matrix);
        matrix->n = size;
        matrix->m = size;
        matrix->matrix = expanded_matrix;
    }
    else
        rc = ERR_MEMORY;
    
    return rc;
}

void copy_square_matrix(int **dst, int **src, int size)
{
    for (int i = 0; i < size; i++)
        for (int j = 0; j < size; j++)
            dst[i][j] = src[i][j];
}

void fill_rows(int **matrix, int old_size, int size)
{
    int var = 0;
    for (int i = old_size; i < size; i++)
        for (int j = 0; j < old_size; j++)
        {
            var = get_mlt_of_column(matrix, i, j);
            if (var < 0)
                var *= -1;
            var = (int)floor(pow(var, 1.0 / i));
            matrix[i][j] = var;
        }
}

int get_mlt_of_column(int **matrix, const int count_cols, const int fix_num)
{
    int mult_value = 1;
    for (int i = 0; i < count_cols; i++)
        mult_value *= matrix[i][fix_num];
    
    return mult_value;
}

void fill_columns(int **matrix, int old_size, int size)
{
    for (int i = 0; i < size; i++)
        for (int j = old_size; j < size; j++)
            matrix[i][j] = get_max_of_row(matrix, i, j);
}

int get_max_of_row(int **matrix, const int fix_col, const int row_size)
{
    int max = matrix[fix_col][0];
    for (int i = 0; i < row_size; i++)
        if (matrix[fix_col][i] > max)
            max = matrix[fix_col][i];
    
    return max;
}

int multiply_matrixes(matrix_t m1, matrix_t m2, matrix_t *m3)
{
    int p = 0, y = 0;
    int rc = scanf("%d%d", &p, &y);
    if (rc != 2 || p < 0 || y < 0)
        return ERR_POWER;

    int **result = allocate_matrix(m1.n, m1.n);
    int **tmp = allocate_matrix(m1.n, m1.n);
    if (result && tmp)
    {
        for (int i = 0; i < m1.n; i++)
            result[i][i] = 1;
        for (int i = 0; i < p; i++)
        {
            memset(tmp[0], 0, m1.n * m1.n * sizeof(int));
            copy_square_matrix(tmp, result, m1.n);
            multiply(tmp, m1.matrix, result, m1.n);
        }
        for (int i = 0; i < y; i++)
        {
            memset(tmp[0], 0, m1.n * m1.n * sizeof(int));
            copy_square_matrix(tmp, result, m1.n);
            multiply(tmp, m2.matrix, result, m1.n);
        }
        free(tmp[0]);
        free(tmp);
        tmp = NULL;
        m3->n = m1.n;
        m3->m = m1.n;
        m3->matrix = result;
    }
    else
        return ERR_MEMORY;

    return SUCCESS;
}

void multiply(int **m1, int **m2, int **result, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = 0; j < size; j++)
        {
            result[i][j] = 0;
            for (int k = 0; k < size; k++)
                result[i][j] += m1[i][k] * m2[k][j];
        }
    }
}

