#include <stdio.h>
#include "constants.h"
#include "matrix.h"
#include "matrix_io.h"
#include "matrix_operations.h"

int main(void)
{
    matrix_t a = { NULL, 0, 0 }, b = { NULL, 0, 0 }, c = { NULL, 0, 0 };
    int rc = SUCCESS;
    rc = read_matrixes(&a, &b);
    if (!rc)
        rc = cut_matrixes(&a, &b);
    if (!rc)
        rc = even_matrixes(&a, &b);
    if (!rc)
        rc = multiply_matrixes(a, b, &c);
    if (!rc)
        print_result(c);
    
    free_all_matrixes(&a, &b, &c);
    return rc;
}

