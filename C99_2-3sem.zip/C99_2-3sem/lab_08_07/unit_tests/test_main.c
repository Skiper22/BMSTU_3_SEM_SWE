#include <stdio.h>
#include "test_operations.h"

int main(void)
{
    int error_amount = 0;
    error_amount += test_operations();
    return error_amount;
}

