make
python3 main.py