#ifndef ARRAY_H_

#define ARRAY_H_

int fill_array_with_fib(int *array, int n);

int transfer_unique(int *src, int *dst, int n);

#endif