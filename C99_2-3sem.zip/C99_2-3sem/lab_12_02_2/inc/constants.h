#ifndef CONSTANTS_H_

#define MAX_LENTH 47
#define OK 0
#define ERR_MEMORY -1

#endif