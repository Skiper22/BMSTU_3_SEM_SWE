#include <stdio.h>
#include <limits.h>
#include <math.h>
#include <stdint.h>
#include <stdlib.h>

#define T 2863311530 //0b10101010101010101010101010
#define BITS 32


void print_binary(uint32_t number)
{
    for (int i = 0; i < BITS; i++)
    {
        uint32_t bit = (number >> (BITS - 1 - i)) & 1;
        printf("%u", bit);
    }
}


uint32_t num_encryption(uint32_t a)
{
    uint32_t result;
    result = (a << 1 & T) | (a >> 1 & T >> 1);
    
    return result;
}

int main(void)
{
    uint32_t num;
    printf("Input number: ");
    int rc = scanf("%u", &num);
    if (rc != 1)
    {
        printf("Error: Expected unsigned integer number\n");

        return EXIT_FAILURE;
    }
    
    if (num > UINT_MAX)
    {
        printf("%d\n", num);
        printf("Error: Value is too big\n");

        return EXIT_FAILURE;
    }
    
    num = num_encryption(num);
    printf("Result: ");
    print_binary(num);

    return EXIT_SUCCESS;
}
