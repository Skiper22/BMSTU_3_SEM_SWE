#!/bin/bash

f1=$1
f2=$2

touch f1_num.txt f2_num.txt
if grep -o -i 'Result: ' "$f1" | wc -l  -ne 1 
then
    exit 1
else
    grep -oE "Result: .*" "$f1" > f1_num.txt
    grep -oE "Result: .*" "$f2" > f2_num.txt
        if cmp f1_num.txt f2_num.txt; then
            exit 0
        else
            exit 1
	fi
fi
