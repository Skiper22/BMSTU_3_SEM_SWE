#!/bin/bash

#г3 ключ(параметр) отладочной информации  для отладчика гбд
gcc -std=c99 -Wall -Werror -Wpedantic -Wextra -Wfloat-equal -Wfloat-conversion -g3 -c ./main.c
gcc -o ./main.exe ./main.c -lm
