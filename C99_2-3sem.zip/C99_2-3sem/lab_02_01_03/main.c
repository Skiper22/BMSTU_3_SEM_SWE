#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define SIZE 10
#define MIN_COUNT_ELEMENT 0

int input_array(int *array, int count_elem_arr)
{
    for (int i = 0; i < count_elem_arr; i++)
        if (scanf("%d", array + i) != 1)
            return EXIT_FAILURE;
    return EXIT_SUCCESS;
}

int find_geometric_mean(int *array, int count_elem_arr, double *geometric_mean)
{
    int count_pos_elem = 0;
    int product_pos_elem = 1;
    for (int i = 0; i < count_elem_arr; i++)
    {
        if (array[i] > 0)
        {
            count_pos_elem++;
            product_pos_elem *= array[i];
        }
    }
    *geometric_mean = pow(product_pos_elem, 1. / count_pos_elem);
    if (count_pos_elem == 0)
        return EXIT_FAILURE;
        
    return EXIT_SUCCESS;
}

int main(void)
{
    int array[SIZE];
    int count_elem_arr;
    printf("Enter number of array elements: ");
    if (scanf("%d", &count_elem_arr) != 1)
    {
        printf("Error value ");
        
        return EXIT_FAILURE;
    }
    
    if (count_elem_arr < MIN_COUNT_ELEMENT || count_elem_arr > SIZE)
        return EXIT_FAILURE;
        
    if (input_array(array, count_elem_arr))
        return EXIT_FAILURE;
    double geometric_mean;

    if (find_geometric_mean(array, count_elem_arr, &geometric_mean))
        return EXIT_FAILURE;
    printf("The geometric mean = %lf", geometric_mean);  
        
    return EXIT_SUCCESS;
}
