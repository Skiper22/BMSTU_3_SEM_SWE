#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define ROW_SIZE 10
#define COLUMN_SIZE 10
#define EXPECTED_COUNT_SIZE 2
#define EXPECTED_COUNT_ELEMENT 1
#define MIN_SIZE 1
#define MAX_SIZE 10
#define MIN_VALUE 0
#define MAX_VALUE 10

#define INPUT_ERR_SIZE 1
#define ERROR_INPUT_MATRIX 2
#define ERR_VALUE_SIZE 3

int input_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; i++)
        for (size_t j = 0; j < column; j++)
            if (EXPECTED_COUNT_ELEMENT != scanf("%d", &matrix[i][j]))
                return ERROR_INPUT_MATRIX;
                
    return EXIT_SUCCESS;
}

void print_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; i++)
    {
        for (size_t j = 0; j < column; j++)
            printf("%d ", matrix[i][j]);
        printf("\n");
    }
}

int min_element(int *array, size_t count_elements)
{
    int min_number = array[0];
    for (size_t i = 1; i < count_elements; ++i)
        if (min_number > array[i])
            min_number = array[i];
    return min_number;
}

void swap_rows(int (*matrix)[COLUMN_SIZE], size_t column, size_t row_1, size_t row_2)
{
    for (size_t i = 0; i < column; ++i)
    {
        int tmp = matrix[row_1][i];
        matrix[row_1][i] = matrix[row_2][i];
        matrix[row_2][i] = tmp;
    }
}

void sort_rows(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; ++i)
        for (size_t j = 0; j < row - i - 1; j++)
            if (min_element(matrix[j], column) < min_element(matrix[j + 1], column))
                swap_rows(matrix, column, j, j + 1);//j and j+1 swap
}

int input_matrix_size(size_t *row, size_t *column)
{
    printf("Input size of matrix: ");
    if (EXPECTED_COUNT_SIZE != scanf("%zu %zu", row, column))
       return INPUT_ERR_SIZE;
       
    if ((*row < MIN_SIZE || *row > MAX_SIZE) || (*column < MIN_SIZE || *column > MAX_SIZE))
        return ERR_VALUE_SIZE;
    
    return EXIT_SUCCESS;
}

int main()
{
    int matrix[ROW_SIZE][COLUMN_SIZE];
    size_t row, column;
    int rc = input_matrix_size(&row, &column);
    if (rc)
        return rc;
      
    if (input_matrix(matrix, row, column) == ERROR_INPUT_MATRIX)
        return ERROR_INPUT_MATRIX;
        
    sort_rows(matrix, row, column);
    print_matrix(matrix, row, column);
    
        
    return EXIT_SUCCESS;
}
