#include <stdio.h>
#include <stdlib.h>

#define SIZE 10
#define MIN_COUNT_ELEMENT 0
#define EXPECTED_COUNT 1

int input_array(int *array, int count_elem_arr)
{
    for (int i = 0; i < count_elem_arr; i++)
        if (scanf("%d", array + i) != EXPECTED_COUNT)
            return EXIT_FAILURE;
    return EXIT_SUCCESS;
}

void output_array(int *array, int size)
{
    for (int i = 0; i < size; i++)
        printf("%d \n", array[i]);
}

int find_reverse(int number)
{
    int number2 = 0;
    while (number > 0)
    {
        int digit = number % 10;
        number /= 10;
        number2 *= 10;
        number2 += digit;
    }
    return number2;
}

void insert_reverse_in_array(int *array, int *count_elem_arr)
{
    for (int i = 0; i < *count_elem_arr; i++)
    {
        if (array[i] > 0)
        {
            *count_elem_arr = *count_elem_arr + 1;
            for (int j = *count_elem_arr; j > i + 1; j--)
                array[j] = array[j - 1];
            array[i + 1] = 0;
        }
    }
    for (int i = 0; i < *count_elem_arr; i++)
        if (array[i] == 0)
            array[i] = find_reverse(array[i - 1]);
}

int main(void)
{
    int array[2 * SIZE];
    int count_elem_arr;
    printf("Enter number of array elements: ");
    if (scanf("%d", &count_elem_arr) != EXPECTED_COUNT)
    {
        printf("Error value ");
        
        return EXIT_FAILURE;
    }
    
    if (count_elem_arr < MIN_COUNT_ELEMENT || count_elem_arr > SIZE)
        return EXIT_FAILURE;
        
    if (input_array(array, count_elem_arr))
        return EXIT_FAILURE;
        
    insert_reverse_in_array(array, &count_elem_arr);
    output_array(array, count_elem_arr);
    return EXIT_SUCCESS;
}
