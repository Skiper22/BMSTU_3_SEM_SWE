#include <stdio.h>
#include <stdlib.h>

int main()
{
    int s = 56;
    printf("Year has %d weeks", s);
    
   return EXIT_SUCCESS;
}
