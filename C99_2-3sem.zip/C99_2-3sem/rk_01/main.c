#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define SIZE 10

int input_array(int arr_size_1)
{
    int array_1[SIZE];
    for ( int i = 0; i < arr_size_1; i++)
    {
        if ((scanf("%d", &array_1[i])) != 1)
            return EXIT_FAILURE;

    }
    int array_2[SIZE];
    int arr_size_2;
    printf("Input size of 2-nd array: \n");
    if (scanf("%d", &arr_size_2) != 1)
    {
        printf("Error: Invalid input\n");

        return EXIT_FAILURE;
    }
    if (arr_size_2 < 0 || arr_size_2 > SIZE)
     {
        printf("Error: Impossible value\n");

        return EXIT_FAILURE;
     }
    for ( int i = 0; i < arr_size_2; i++)
    {
        if ((scanf("%d", &array_2[i])) != 1)
            return EXIT_FAILURE;
        if (array_2[i] != 1 || array_2[i] != -1)
            return EXIT_FAILURE;     
    }
    for ( int i = 0; i < arr_size_2; i++)
    {
        if (array_2[i] == 1)
        {
            for (int j = 1; j < arr_size_1; j++)
            {
                if (array_1[j - 1] == array_1[j])
                {
                       array_1[j] *= 2;
                       array_1[j - 1] = 0;
                }        
            }
        }

        if (array_2[i] != 1)
        {
            for (int j = arr_size_1; j > 0; j--)
            {
                if (array_1[j - 1] == array_1[j])
                {
                       array_1[j] *= 2;
                       array_1[j - 1] = 0;
                }
            }
        }

    }
 
    for ( int i = 0; i < arr_size_1; i++)
        if (array_1[i] != 0)
            printf("%d ", array_1[i]);
    return EXIT_SUCCESS;
}



int main(void)
{
    int arr_size_1;
    printf("Input size of 1-st array: \n");
    if (scanf("%d", &arr_size_1) != 1)
    {
        printf("Error: Invalid input\n");

        return EXIT_FAILURE;
    }
    if (arr_size_1 < 0 || arr_size_1 > SIZE)
    {
        printf("Error: Impossible value\n");

        return EXIT_FAILURE;
    }

    if (input_array(arr_size_1))
        return EXIT_FAILURE;
    return EXIT_SUCCESS;
}

