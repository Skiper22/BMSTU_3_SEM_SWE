#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define PI 3.141593
#define GRADUS 180

int main()
{
    double a, b, angle;
    scanf("%lf %lf %lf", &a, &b, &angle);
    angle = angle * PI / GRADUS;
    double square = 0.5 * a * b * sin(angle);
    printf("%lf", square);
    
    return EXIT_SUCCESS;
}
