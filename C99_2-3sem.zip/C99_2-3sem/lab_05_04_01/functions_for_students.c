#include <stdlib.h>
#include "functions_for_students.h"
#include "defines.h"

#define SWAP(x, y) {student_t SWAP = x; x = y; y = SWAP; }

int modification(int count_arguments, char *str)
{
    if ((count_arguments == 3) && (strcmp(str, "st") == 0))
        return 1;
    if ((count_arguments == 5) && (strcmp(str, "ft") == 0))
        return 2;
    if ((count_arguments == 3) && (strcmp(str, "dt") == 0))
        return 3;
    
    return ERROR_ARGS;
}
int file_exist(FILE *f)
{
    if (f == NULL)
        return ERROR_FIND_FILE;
    
    return EXIT_SUCCESS;
}

int read_students(FILE *f, student_t arr[MAX_ARR_SIZE], size_t *n)
{
    int rc = EXIT_SUCCESS;

    while (fscanf(f, "%s %s", arr[*n].surname, arr[*n].name) == 2)
    {
        for (size_t i = 0; i < COUNT_MARKS; i++)
        {
            rc = fscanf(f, "%u", &arr[*n].marks[i]);
            if (!rc)
                return ERROR_DATA;
        }
        (*n)++;
        if (*n > MAX_ARR_SIZE)
            return ERROR_DATA;
    }
    
    return EXIT_SUCCESS;
}

void print_student(student_t st)
{
    printf("%s \n", st.surname);
    printf("%s \n", st.name);
    printf("%u %u %u %u \n", st.marks[0], st.marks[1], st.marks[2], st.marks[3]);
}

void print_students(student_t *arr, int n)
{
    for (int i = 0; i < n; i++)
        print_student(arr[i]);
}


void sort_students(student_t *arr, int count_students)
{
    for (int i = 0; i < count_students - 1; i++)
        for (int j = i + 1; j < count_students; j++)
        {
            if (strcmp(arr[i].surname, arr[j].surname) > 0)
                SWAP(arr[i], arr[j])
            else
            {
                if (strcmp(arr[i].surname, arr[j].surname) == 0)
                    if (strcmp(arr[i].name, arr[j].name) > 0)
                        SWAP(arr[i], arr[j])
            }
        }
}

void print_student_file(FILE *f, student_t st)
{
    fprintf(f, "%s \n", st.surname);
    fprintf(f, "%s \n", st.name);
    fprintf(f, "%u %u %u %u \n", st.marks[0], st.marks[1], st.marks[2], st.marks[3]);
}

int surname_substr(FILE *f, student_t *arr, int n, char *str)
{   
    int k = 0;
    for (int i = 0; i < n; i++)
        if (strstr(arr[i].surname, str) != NULL)
        {
            print_student_file(f, arr[i]);
            k++;
        }
        
    return k == 0 ? ERROR_EMPTY : EXIT_SUCCESS; 
}

double arithmetic_value_all_students(student_t arr[MAX_ARR_SIZE], int count_students)
{
    double arithmetic_value = 0;
    for (int i = 0; i < count_students; i++)
        for (int j = 0; j < 4; j++)
            arithmetic_value += arr[i].marks[j];
    arithmetic_value /= count_students * 4;
    
    return arithmetic_value;
}

double arithmetic_value_student(uint32_t arr[4], int count_marks)
{
    double arithmetic_value = 0;
    for (int i = 0; i < count_marks; i++)
        arithmetic_value += arr[i];
    arithmetic_value /= count_marks;
    
    return arithmetic_value;
}

int del_students(FILE *f, student_t arr[MAX_ARR_SIZE], int n)
{
    int k = 0;
    double arithmetic_value_students = arithmetic_value_all_students(arr, n);
    for (int i = 0; i < n; i++)
        if (arithmetic_value_student(arr[i].marks, 4) > arithmetic_value_students || \
            fabs(arithmetic_value_student(arr[i].marks, 4) - arithmetic_value_students) < EPS)
        {
            print_student_file(f, arr[i]);
            k++;
        }
        
    return k == 0 ? ERROR_EMPTY : EXIT_SUCCESS; 
}
