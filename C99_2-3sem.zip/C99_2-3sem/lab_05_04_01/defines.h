#ifndef __DEFINES__H__
#define __DEFINES__H__

#define ERROR_ARGS 53
#define ERROR_FIND_FILE 1
#define ERROR_DATA 2
#define ERROR_EMPTY 3

#define MAX_SURNAME 25
#define MAX_NAME 10
#define N 4
#define MAX_ARR_SIZE 100
#define EPS 1e-08
#define COUNT_MARKS 4

#include <stdint.h>

typedef struct
{
    char surname[MAX_SURNAME + 1];
    char name[MAX_NAME + 1];
    uint32_t marks[N];
} student_t;


#endif
