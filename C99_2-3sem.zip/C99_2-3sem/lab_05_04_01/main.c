#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "functions_for_students.h"
#include "defines.h"

int main(int argc, char **argv)
{
    int key = modification(argc, argv[1]);
    if (key == ERROR_ARGS)
        return ERROR_ARGS;
        
    FILE *f_in, *f_out;
    student_t arr[MAX_ARR_SIZE];
    int rc = EXIT_SUCCESS;
    size_t n = 0;
    
        
    switch (key)
    {
        case 1:
            f_in = fopen(argv[2], "r");
            if (file_exist(f_in))
                return ERROR_FIND_FILE;
            rc = read_students(f_in, arr, &n);
            if (rc || n == 0)
            {
                fclose(f_in);
                return ERROR_DATA;
            }
            else
            {
                sort_students(arr, n);
                print_students(arr, n);
            }
            fclose(f_in);
            break;
        case 2:
            f_in = fopen(argv[2], "r");
            if (file_exist(f_in))
                return ERROR_FIND_FILE;
            f_out = fopen(argv[3], "w");
            rc = read_students(f_in, arr, &n);
            if (rc || n == 0)
            {
                fclose(f_in);
                
                return ERROR_DATA;
            }
            rc = surname_substr(f_out, arr, n, argv[4]);
            if (rc)
            {
                fclose(f_in);
                fclose(f_out);
                return ERROR_EMPTY;
            }
            fclose(f_out);
            fclose(f_in);
            break;
        case 3:
            f_in = fopen(argv[2], "r");
            if (file_exist(f_in))
                return ERROR_FIND_FILE;
            rc = read_students(f_in, arr, &n);
            if (rc || n == 0)
            {
                fclose(f_in);
                return ERROR_DATA;
            }
            fclose(f_in);
            f_in = fopen(argv[2], "w");
            rc = del_students(f_in, arr, n);
            fclose(f_in);
            if (rc)
                return ERROR_EMPTY;
            break;
    }
       
    return rc;
}
