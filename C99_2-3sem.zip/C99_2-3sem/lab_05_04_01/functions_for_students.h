#ifndef __FUNCTIONS_FOR_STUDENTS__H__
#define __FUNCTIONS_FOR_STUDENTS__H__

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "defines.h"

int modification(int count_arguments, char *str);
int file_exist(FILE *f);
int read_students(FILE *f, student_t arr[MAX_ARR_SIZE], size_t *n);
void print_student(student_t st);
void print_students(student_t *arr, int n);
void sort_students(student_t *arr, int count_students);
void print_student_file(FILE *f, student_t st);
int surname_substr(FILE *f, student_t *arr, int n, char *str);
double arithmetic_value_all_students(student_t arr[MAX_ARR_SIZE], int count_students);
double arithmetic_value_student(uint32_t arr[4], int count_marks);
int del_students(FILE *f, student_t arr[MAX_ARR_SIZE], int n);

#endif
