#!/bin/bash

f1=$1
f2=$2

if [ "$(grep -Eo ".*" "$f1")" == "$(grep -Eo ".*" "$f2")" ]; then
	exit 0
else
	exit 1
fi

