#ifndef _CHECK_PRIME_H
#define _CHECK_PRIME_H

#include <limits.h>

#define SIMPLE    1
#define NO_SIMPLE 0

int check_simple_num(int num);
int get_simple_num(int num);

#endif //_CHECK_PRIME_H
