#ifndef _PRINT_LIST_H
#define _PRINT_LIST_H

#include <stdio.h>
#include <stdlib.h>

#include "struct_list.h"
#include "errors.h"

#define SYMBOL_PRINT  "L"

int print_list(node_t *head);

#endif //_PRINT_LIST_H
