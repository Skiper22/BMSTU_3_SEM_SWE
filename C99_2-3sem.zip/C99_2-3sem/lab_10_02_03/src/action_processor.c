#include "action_processor.h"

int action_out(void)
{
    int rc = EXIT_SUCCESS;
    
    int num = 0;
    if (!(rc = read_num(&num)))
    {
        node_t *list = NULL;
        if (!(rc = translate_num_in_list(&list, num)))
            rc = print_list(list);
        free_list(&list);
    }
    
    return rc;
}

int action_mul(void)
{
    int rc = EXIT_SUCCESS;
    
    int num_1 = 0, num_2 = 0;
    if (!(rc = read_num(&num_1)))
    {
        if (!(rc = read_num(&num_2)))
        {
            node_t *list_1 = NULL, *list_2 = NULL, *result = NULL;
            if (!(rc = translate_num_in_list(&list_1, num_1)))
            {
                if (!(rc = translate_num_in_list(&list_2, num_2)))
                {
                    if (!(rc = multiply_lists(&result, list_1, list_2)))
                        rc = print_list(result);
                }
            }
            free_list(&list_1);
            free_list(&list_2);
            free_list(&result);
        }
    }
    
    return rc;
}


int action_div(void)
{
    int rc = EXIT_SUCCESS;
    
    int num_1 = 0, num_2 = 0;
    if (!(rc = read_num(&num_1)))
    {
        if (!(rc = read_num(&num_2)))
        {
            node_t *list_1 = NULL, *list_2 = NULL, *result = NULL;
            if (!(rc = translate_num_in_list(&list_1, num_1)))
            {
                if (!(rc = translate_num_in_list(&list_2, num_2)))
                {
                    if (!(rc = divide_lists(&result, list_1, list_2)))
                        rc = print_list(result);
                }
            }
            free_list(&list_1);
            free_list(&list_2);
            free_list(&result);
        }
    }
    
    return rc;
}


int action_sqr(void)
{
    int rc = EXIT_SUCCESS;
    
    int num = 0;
    if (!(rc = read_num(&num)))
    {
        node_t *result = NULL, *list = NULL;
        if (!(rc = translate_num_in_list(&list, num)))
        {
            if (!(rc = sqr_list(&result, list)))
                rc = print_list(result);
        }
        free_list(&list);
        free_list(&result);
    }
    
    return rc;
}
