#ifndef __DEFINES__H__
#define __DEFINES__H__


#define ERROR_FIND_FILE 1
#define ERROR_DATA 2
#define ERROR_EMPTY 3

#define MAX_COUNT_WORDS 25
#define MAX_LEN_STR 11

#define COUNT_ARGS 2
#define ERROR_ARGS 3

typedef struct
{
    int count_words;
    char words[MAX_COUNT_WORDS][MAX_LEN_STR];
} text_t;


#endif
