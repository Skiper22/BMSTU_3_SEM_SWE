#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "functions_for_text.h"
#include "defines.h"

int main(int argc, char **argv)
{
    int rc = EXIT_SUCCESS;
    if (argc < COUNT_ARGS)
        return ERROR_ARGS;
    FILE *f;
    f = fopen(argv[1], "r");
    if (file_exist(f))
        return ERROR_FIND_FILE;
    text_t a;
    rc = read_data(f, &a);
    if (rc)
        return rc;
    print_words(&a);
       
    return rc;
}
