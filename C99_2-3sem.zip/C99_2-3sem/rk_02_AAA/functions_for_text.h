#ifndef __FUNCTIONS_FOR_TEXT__H__
#define __FUNCTIONS_FOR_TEXT__H__

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "defines.h"

int file_exist(FILE *f);
int read_data(FILE *f, text_t *a);
void revstr(char *str1);
void print_words(text_t *a);

#endif
