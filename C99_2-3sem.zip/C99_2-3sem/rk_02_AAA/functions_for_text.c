#include <stdlib.h>
#include "functions_for_text.h"
#include "defines.h"
#include <string.h>

#define SWAP(x, y) {student_t SWAP = x; x = y; y = SWAP; }

int file_exist(FILE *f)
{
    if (f == NULL)
        return ERROR_FIND_FILE;
    
    return EXIT_SUCCESS;
}

int read_data(FILE *f, text_t *a)
{
    int n = 0;

    while (fscanf(f, "%s", a->words[n]) == 1)
    {
        n++;
        if (n > MAX_COUNT_WORDS)
            return ERROR_DATA;
    }
    a->count_words = n++;
    
    return EXIT_SUCCESS;
}

void revstr(char *str1)  
{    
    int i, len, temp;  
    len = strlen(str1);
       
    for (i = 0; i < len/2; i++)  
    {    
        temp = str1[i];  
        str1[i] = str1[len - i - 1];  
        str1[len - i - 1] = temp;  
    }  
}  

void print_words(text_t *a)
{
        /*
    int n = a->count_words;
    for (int i = n; i >= 0; i--)
    {
        char *str = a->words[i];
        revstr(str);
        printf("%s ", str);
    }
    */
    FILE *f;
    f = fopen("out.txt", "w");
    int n = a->count_words;
    for (int i = n; i >= 0; i--)
    {
        char *str = a->words[i];
        revstr(str);
        fprintf(f, "%s ", str);
    }
    fclose(f);
}

