#!/bin/bash

gcc -std=c99 -Wall -Werror -Wpedantic -Wextra -Wfloat-conversion -g3 -c ./main.c
gcc -o ./main.exe ./main.c -lm
