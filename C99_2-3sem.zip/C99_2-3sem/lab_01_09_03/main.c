#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define BOTTOM_LINE  0

double find_function_value(double x, int rc)
{
    double product = 1;
    for (int t = 1; x >= 0 && rc == 1; t++)
    {
        product *= (x + t);
        rc = scanf("%lf", &x);
    }

    if (rc == 1 && x < 0)
        return product;
        
    return EXIT_SUCCESS;
}

int main(void)
{
    double x;
    int rc;
    rc = scanf("%lf", &x);
    if (rc != 1 || x < BOTTOM_LINE)
    {
        printf("Input error");

        return EXIT_FAILURE;
    }
    
    double product = find_function_value(x, rc);

    if (product)
    {
        printf("%lf\n", exp(1 / product));

        return EXIT_SUCCESS;
    }
        
    return EXIT_FAILURE;
}

