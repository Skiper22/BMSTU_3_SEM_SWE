#ifndef KEY_H
#define KEY_H

#define ARRAY_SRC_EMPTY    20
#define ARRAY_DST_EMPTY    21
#define MEMORY_ERR         22

double calc_average(const int *arr_beg, const int *arr_end);
int key(const int *pb_src, const int *pe_src, int **pb_dst, int **pe_dst);

#endif
