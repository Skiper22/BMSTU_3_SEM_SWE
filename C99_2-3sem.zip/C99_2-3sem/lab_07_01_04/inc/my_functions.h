#include <stdio.h>
#ifndef MY_FUNCTIONS_H
#define MY_FUNCTIONS_H

#define ERR_MEMORY    30
#define ERROR_DATA    31

void get_count_elements(FILE *f, int *count_elements);
int create_array(FILE *f_in, int **array, int *count_elements);
int read_array(FILE *f, int *array, int n);
void fprint(FILE *f, const int *arr_beg, const int *arr_end);
void f_close(FILE *f1, FILE *f2);
#endif
