#include <stddef.h>

#ifndef SORT_H
#define SORT_H

void swap(void *el1, void *el2, size_t size);
int cmp_int(const void *l, const void *r);
void mysort(void *base, size_t n, size_t size, int (*cmp)(const void *, const void *));

#endif
