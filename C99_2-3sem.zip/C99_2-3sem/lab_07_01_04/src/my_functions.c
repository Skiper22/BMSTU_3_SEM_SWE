#include <stdlib.h>
#include "my_functions.h"

void get_count_elements(FILE *f, int *count_elements)
{
    int rc, element, i = 0;
    while ((rc = fscanf(f, "%d", &element)) == 1)
        i++;
    *count_elements = i;
    rewind(f);
}

int create_array(FILE *f_in, int **array, int *count_elements)
{
    int rc = EXIT_SUCCESS;
    get_count_elements(f_in, count_elements);
    *array = malloc(sizeof(int) * (*count_elements));
    if (!(*array))
        rc = ERR_MEMORY;
    if (*count_elements == 0)
        return ERROR_DATA;
    
    return rc;
}

int read_array(FILE *f, int *array, int n)
{
    for (int i = 0; i < n; i++)
        if (fscanf(f, "%d", array + i) != 1)
            return EXIT_FAILURE;
    rewind(f);

    return EXIT_SUCCESS;
}

void fprint(FILE *f, const int *arr_beg, const int *arr_end)
{
    for (int i = 0; i < arr_end - arr_beg; i++)
        fprintf(f, "%d ", *(arr_beg + i));
}

void f_close(FILE *f1, FILE *f2)
{
    fclose(f1);
    fclose(f2);
}
