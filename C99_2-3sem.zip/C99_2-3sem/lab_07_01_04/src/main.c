#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "key.h"
#include "my_functions.h"
#include "sort.h"

#define ARG_ERR          10
#define ERR_FIND_FILE    11
#define NOT_FOUND_FILE   12
#define ERR_DATA         13


int main(int argc, char **argv)
{
    int rc = EXIT_SUCCESS;
    FILE *f_in, *f_out;
    if (!(argc == 3 || (argc == 4 && !strcmp(argv[3], "f"))))
       return ARG_ERR;
    
    f_in = fopen(argv[1], "r");
    if (f_in == NULL)
        return ERR_FIND_FILE;
    
    f_out = fopen(argv[2], "w");
    if (f_out == NULL)
    {
        fclose(f_in);
        
        return NOT_FOUND_FILE;
    }
    
    int *array = NULL, count_elements = 0;
    
    rc = create_array(f_in, &array, &count_elements);
    if (rc)
    {
        free(array);
        f_close(f_out, f_in);
        
        return ERR_DATA;
    }
    
    if ((rc = read_array(f_in, array, count_elements)))
    {
        f_close(f_out, f_in);
        
        return rc;
    }
    mysort(array, count_elements, sizeof(*array), cmp_int);
    
    int *pb_dst = NULL, *pe_dst = NULL;
    int cmd = 0;
    if (argc == 3)
        cmd = 1;
    if (argc == 4)
        cmd = 2;
    
    switch (cmd)
    {
        case 1:
            fprint(f_out, array, (array + count_elements));
            break;
        case 2:
            rc = key(array, (array + count_elements), &pb_dst, &pe_dst);
            if (!rc)
                fprint(f_out, pb_dst, pe_dst);
            break;
    }
    
    f_close(f_out, f_in);
    free(array);
    free(pb_dst);
    
    return rc;
}
