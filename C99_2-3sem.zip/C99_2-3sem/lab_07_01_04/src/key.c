#include <stddef.h>
#include <stdlib.h>
#include "key.h"

double calc_average(const int *arr_beg, const int *arr_end)
{
    double avr = 0;
    for (const int *i = arr_beg; i < arr_end; i++)
        avr += *i;
    if (avr != 0)
        avr /= (arr_end - arr_beg);
    
    return avr;
}

int key(const int *pb_src, const int *pe_src, int **pb_dst, int **pe_dst)
{
    double avr = 0;
    
    int len_dst = 0;
    if (pe_src < pb_src)
        return ARRAY_SRC_EMPTY;
    
    avr = calc_average(pb_src, pe_src);
    for (const int *i = pb_src; i < pe_src; i++)
        if (*i > avr)
            len_dst++;
    if (len_dst == 0)
        return ARRAY_DST_EMPTY;
    *pb_dst = malloc(len_dst * sizeof(int));
    if (*pb_dst == NULL)
        return MEMORY_ERR;
    *pe_dst = *pb_dst + len_dst;
    int *j = *pb_dst;
    for (const int *i = pb_src; i < pe_src; i++)
        if (*i > avr)
        {
            *j = *i;
            j++;
        }
    
    return EXIT_SUCCESS;
}
