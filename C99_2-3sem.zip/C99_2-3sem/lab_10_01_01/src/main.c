#include "../inc/main.h"
#include "../inc/functions.h"

int main(void)
{
    return EXIT_SUCCESS;
}

