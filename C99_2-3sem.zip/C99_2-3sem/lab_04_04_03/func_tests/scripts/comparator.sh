#!/bin/bash

f1=$1
f2=$2

if [ "$(grep -Eo 'YES|NO' "$f1")" == "$(grep -Eo 'YES|NO' "$f2")" ]; then
	exit 1
else
	exit 0
fi
