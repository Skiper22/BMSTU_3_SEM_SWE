#!/bin/bash
# записать в файл имена тестовых файлов а потом извлекать данные из файла в массивы 
arr_pos_in=()
while IFS='' read -r line; do arr_pos_in+=("$line"); done < <(ls ../data/pos_[0-9][0-9]_in.txt)

arr_pos_out=()
while IFS='' read -r line; do arr_pos_out+=("$line"); done < <(ls ../data/pos_[0-9][0-9]_out.txt)

arr_neg_in=()
while IFS='' read -r line; do arr_neg_in+=("$line"); done < <(ls ../data/neg_[0-9][0-9]_in.txt)

arr_pos_args=()
while IFS='' read -r line; do arr_pos_args+=("$line"); done < <(ls ../data/pos_[0-9][0-9]_args.txt)

arr_neg_args=()
while IFS='' read -r line; do arr_neg_args+=("$line"); done < <(ls ../data/neg_[0-9][0-9]_args.txt)


success_pos_count=0


success_neg_count_memory=0


success_pos_count_memory=0


count_pos_elem=${#arr_pos_in[@]}
count_neg_elem=${#arr_neg_in[@]}

success_neg_count=0


if [ -v USE_VALGRIND ]; then
   
    for (( item=0 ; item<count_pos_elem ; item++))
    do
        ./pos_case.sh "${arr_pos_in[item]}" "${arr_pos_out[item]}" "${arr_pos_args[item]}"
        codv=$?
        if [ "$codv" == "0" ]; then
            success_pos_count=$((success_pos_count + 1))
            success_pos_count_memory=$((success_pos_count_memory + 1))
        elif [ "$codv" == "2" ]; then
            success_pos_count_memory=$((success_pos_count_memory + 1))
        elif [ "$codv" == "3" ]; then
            success_pos_count=$((success_pos_count + 1))
        fi
        
    done
	
    for (( item=0 ; item<count_neg_elem ; item++))
    do
        ./neg_case.sh "${arr_neg_in[item]}" "${arr_neg_args[item]}"
        codv=$?
        if [ "$codv" == "0" ]; then
            success_neg_count=$((success_neg_count + 1))
            success_neg_count_memory=$((success_neg_count_memory + 1))
        elif [ "$codv" == "1" ]; then
            success_neg_count=$((success_neg_count + 1))
        elif [ "$codv" == "2" ]; then
            success_neg_count_memory=$((success_neg_count_memory + 1))
        fi
    done

else
    for (( item=0 ; item<count_pos_elem ; item++)) 
    do
	./pos_case.sh "${arr_pos_in[item]}" "${arr_pos_out[item]}" "${arr_pos_args[item]}"
        codv=$?
        if [ "$codv" == "5" ]; then
            success_pos_count=$((success_pos_count + 1))
        fi
    done

    for (( item=0 ; item<count_neg_elem ; item++))
    do
	./neg_case.sh "${arr_neg_in[item]}" "${arr_neg_args[item]}"
        codv=$?
        if [ "$codv" == "4" ]; then
            success_neg_count=$((success_neg_count + 1))
        fi
    done

fi

if [ -v USE_VALGRIND ]; then
    
    echo "Positive tests: correct $success_pos_count of $count_pos_elem; memory passed $success_pos_count_memory of $count_pos_elem"
    if [ "$count_neg_elem" -eq 0 ]; then
        echo "There are no negative 'in' files"
    else
    	echo "Negative tests: correct $success_neg_count of $count_neg_elem; memory passed $success_neg_count_memory of $count_neg_elem"
    fi
else 
    echo "Positive tests: correct $success_pos_count of $count_pos_elem"
    
    if [ "$count_neg_elem" -eq 0 ]; then
        echo "There are no negative 'in' files"
    else
    	echo "Negative tests: correct $success_neg_count of $count_neg_elem"
    fi
fi
