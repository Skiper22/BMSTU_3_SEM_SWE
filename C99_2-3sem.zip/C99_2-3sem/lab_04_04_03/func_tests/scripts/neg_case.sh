#!/bin/bash

file_stream_in=$1
touch neg_out.txt

if [ -v USE_VALGRIND ]; then #Проверка на то , поднят ли глобальный флаг USE_VALGRIND,если да, то все тестовые прогоны проводятся в оболочке valgrind, иначе — как обычно.
    if [ -n "$2" ]; then
        file_app_args=$2
    else
        file_app_args=""
    fi
    valgrind --log-file=log.txt --quiet ./../../app.exe "$file_app_args" < "$file_stream_in" > neg_out.txt
    codv=$?
    if [ -s log.txt ]; then
    	val_cod="1" # файл непустой
    else
    	val_cod="0" # файл пустой
    fi
    if [ "$codv" != "0" ] && [ "$val_cod" == "0" ]; then
        exit 0
    elif [ "$codv" != "0" ] && [ "$val_cod" != "0" ]; then
        exit 1
    elif [ "$codv" == "0" ] && [ "$val_cod" == "0" ]; then
        exit 2
    else
        exit 3
    fi
    
else
    if [ -n "$2" ]; then
        file_app_args=$2
    else
        file_app_args=""
    fi
    ./../../app.exe "$file_app_args" < "$file_stream_in" > neg_out.txt
    codv=$?
    if [ "$codv" != "0" ]; then
    	exit 4
    else 
        exit 5
    fi
fi
