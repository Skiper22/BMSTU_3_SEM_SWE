#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_STR_LEN 256
#define OK 0
#define STR_LEN_ERR -1

int read_line(char *string, int size, int *len)
{
    int ch, i = 0;
    while ((ch = getchar()) != '\n' && ch != EOF)
    {
        if (size - 1 < i)
            return STR_LEN_ERR;
        string[i++] = ch;
    }
    string[i] = '\0';
    *len = i;
    if (strlen(string) > MAX_STR_LEN)
        return STR_LEN_ERR;
    
    return OK;
}

void shift_left(char *string)
{
    while (*string)
    {
        *string = *(string + 1);
        string++;
    }
}

void my_strip(char *str, int len)
{
    while (*str == ' ' || *str == '\t' || *str == '\n')
    {
        shift_left(str);
        len--;
    }
    while (str[len - 1] == ' ' || str[len - 1] == '\t' || str[len - 1] == '\n')
        len--;
    str[len] = 0;
}

int my_lfind(char *str, char ch)
{
    int i = 0;
    while (str[i])
    {
        if (str[i] == ch)
            return i;
        i++;
    }
    
    return -1;
}

int is_digit(char ch)
{
    return (ch >= '0' && ch <= '9');
}

int is_digit_sequence(char *str, int index, int len)
{
    for (int i = 0; i < len; i++)
    {
        if (is_digit(str[index++]) == 0)
            return 0;
    }
    
    return 1;
}

int is_phone_number(char *str, int len)
{
    my_strip(str, len);
    int lbracket_index = my_lfind(str, '('), index = 0;
    int rbracket_index = my_lfind(str, ')');
    if (rbracket_index == -1)
        return 0;
    if (rbracket_index - lbracket_index != 4)
        return 0;
    if (lbracket_index == -1)
        return 0;
    if (str[index] != '+' && str[index] != '(')
        return 0;
    if (str[index] == '+')
    {
        index++;
        while (str[index] != '(')
        {
            if (is_digit(str[index]) == 0)
                return 0;
            index++;
        }
    }
    index++;
    while (str[index] != ')')
    {
        if (is_digit(str[index]) == 0)
            return 0;
        index++;
    }
    index++;
    if (str[index] != '-')
        return 0;
    index++;
    if (!is_digit_sequence(str, index, 3))
        return 0;
    index += 3;
    if (str[index] != '-')
        return 0;
    index++;
    if (!is_digit_sequence(str, index, 2))
        return 0;
    index += 2;
    if (str[index] != '-')
        return 0;
    index++;
    if (!is_digit_sequence(str, index, 2))
        return 0;
    index += 2;
    if (str[index] != 0)
        return 0;
        
    return 1;
}
int main(void)
{
    char str[MAX_STR_LEN + 1];
    int len, check, result;
    check = read_line(str, MAX_STR_LEN + 1, &len);
    
    if (check != 0)
        return check;
    result = is_phone_number(str, len);
    printf("%s", result ? "YES" : "NO");
    
    return OK;
}
