#!/bin/bash

rm ./app.exe ./main.o ./main.c.gcov ./main.gcno ./main.gcda
