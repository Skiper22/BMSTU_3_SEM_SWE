#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LEN 256
#define MAX_LEN_WORD 16
#define MIN_REPEAT 1
#define RAISED 1
#define EMPTY 0
#define EQUAL 0
#define WORDS_LIMIT 2

#define INPUT_SUCCESS 1
#define INPUT_ERROR 2
#define SIZE_OVERFLOW 3
#define OUTPUT_ERROR 4
#define SUCCESS_OUTPUT 5
#define SUCCESS 0
#define ERROR_EMPTY_STR 7
#define WORD_EMPTY_ERR 8
#define WORD_ONE_ERR 9
#define ERR_OVERFLOW 10
#define STR_EMPTY_ERR 11

#define _GNU_SOURCE
#define _POSIX_C_SOUCRE 200809L

int input_string(char *str)
{
    if (fgets(str, MAX_LEN + 2, stdin) == NULL)
        return INPUT_ERROR;
    if (strlen(str) > MAX_LEN)
        return ERR_OVERFLOW;
    if (strlen(str) == 1)
        return STR_EMPTY_ERR;
    if (str[strlen(str) - 1] == '\n')
        str[strlen(str) - 1] = '\0';
        
    return SUCCESS;
}

int check_separator_str(char *str)
{
    int i = 0, j = 0;
    while (str[i] != '\0')
    {
        if (strchr(" ,;:-.!?", str[i]) != NULL)
            j = 0;
        else
            j++;
            
        if (j > MAX_LEN - 1)
            return ERR_OVERFLOW;
        i++;
    }
    
    return EXIT_SUCCESS;
}

int get_array_words(char (*const arr_word)[MAX_LEN], size_t *count_words, char *const str)
{
    char *word;
    int i = 0;
    word = strtok(str, " ,;:-.!?");
    
    while (word != NULL)
    {
        if (i > MAX_LEN_WORD)
            return SIZE_OVERFLOW;

        strcpy(arr_word[i], word);
        i++;
        if (strlen(word) > MAX_LEN_WORD)
            return SIZE_OVERFLOW;
        word = strtok(NULL, " ,;:-.!?");   
    }
    if (i == 0)
        return WORD_EMPTY_ERR;
    *count_words = (size_t)i;
    
    return SUCCESS;
}

void del_repeat_sym(char *str, char *stro)
{
    int i = 1, j = 1;
    stro[0] = str[0];
    stro[1] = '\0';
    while (str[i] != '\0')
    {
        if (strchr(stro, str[i]) == NULL)
        {
            stro[j] = str[i];
            stro[j + 1] = '\0';
            j++;
        }
        i++;
    }
}

int creating_new_str(char (*const arr_word)[MAX_LEN], size_t *count_words, char *const new_str)
{
    char word[MAX_LEN] = { 0 };
    char *last_word = arr_word[*count_words - 1];
    for (int i = *count_words - 2; i >= 0; --i)
    {
        if (strcmp(last_word, arr_word[i]))
        {
            if (i != *count_words - 2)
                strcat(new_str, " ");
            del_repeat_sym(arr_word[i], word);
            strcat(new_str, word);
        }
    }
    if (strlen(new_str) == EMPTY)
        return ERROR_EMPTY_STR;
         
    return SUCCESS;
}

void output_str(char *const new_str)
{
    printf("Result: %s\n", new_str);
}

int main()
{ 
    char str[MAX_LEN] = "";
    char new_str[MAX_LEN] = "";
    size_t size = 0;
    char arr_word[MAX_LEN][MAX_LEN] = { "" };

    int rc = input_string(str);
    if (rc)
        return rc;
    if (check_separator_str(str) == ERR_OVERFLOW)
        return ERR_OVERFLOW;
    rc = get_array_words(arr_word, &size, str);
    if (rc)
        return rc;
    if (creating_new_str(arr_word, &size, new_str) == ERROR_EMPTY_STR)
        return ERROR_EMPTY_STR;
    output_str(new_str);

    return EXIT_SUCCESS;
}

