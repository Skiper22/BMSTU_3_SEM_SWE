/* 
При работе с целыми числами используется тип int
Алгоритм сортировки - пузырьковый метод
Порядок чисел осуществляется по возрастанию 
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "work_with_binary_file.h"
#include "defines.h"

int main(int argc, char **argv)
{
    int rc = EXIT_SUCCESS;
    
    int key = modification(argc, argv[1]);
    int count_numbers;
    
    switch (key)
    {
        case 0:
            rc = ERROR_ARGUMENTS;
            break;
        case 1:
            count_numbers = atoi(argv[2]);
            rc = create_bin(argv[3], count_numbers);
            break;
        case 2:
            rc = output_bin(argv[2]);
            break;
        case 3:
            rc = sort_bin(argv[2]);
            break;
    }
        
    return rc;
}
