#ifndef __DEFINES__H__
#define __DEFINES__H__

#define ERROR_DATA 1
#define K 1000
#define ERROR_EMPTY_FILE 2
#define ERROR_FILE_SIZE_DETECTION 3
#define ERROR_READ_DATA 4
#define ERROR_WRITE_DATA 5
#define ERROR_ARGUMENTS 6
#define ERROR_WRITE 7
#define ERROR_IO 8
#define NOT_FOUND_FILE 9
#define ERR_PARAM -1

#endif
