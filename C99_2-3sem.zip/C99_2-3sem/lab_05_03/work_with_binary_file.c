#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <string.h>
#include "work_with_binary_file.h"
#include "defines.h"

int modification(int count_arguments, char *str)
{
    if ((count_arguments == 4) && (strcmp(str, "c") == 0))
        return 1;
    if ((count_arguments == 3) && (strcmp(str, "p") == 0))
        return 2;
    if ((count_arguments == 3) && (strcmp(str, "s") == 0))
        return 3;
    
    return 0;
}

int create_bin(char *filename, const int count)
{
    FILE *f;
    f = fopen(filename, "wb");
    if (f == NULL)
        return NOT_FOUND_FILE;
    srand(time(NULL));
    int num;
    for (int i = 0; i < count; i++)
    {
        num = rand() % K;
        int rc = fwrite(&num, sizeof(int), 1, f);
        if (rc != 1)
            return ERROR_WRITE_DATA;
    }
    fclose(f);
    
    return EXIT_SUCCESS;
}

int file_size(FILE *f, size_t *size)
{    
    long sz;
    if (fseek(f, 0L, SEEK_END))
        return ERROR_EMPTY_FILE;
    sz = ftell(f);
    if (sz < 0)
        return ERROR_EMPTY_FILE;
    *size = sz;

    return fseek(f, 0L, SEEK_SET);
}

int output_bin(char *filename)
{
    FILE *f;
    f = fopen(filename, "rb");
    if (f == NULL)
        return NOT_FOUND_FILE;
    size_t size;
    int num;
    int rc = 0;

    rc = file_size(f, &size);
    if (rc || (size < sizeof(int)))
        return ERROR_EMPTY_FILE;
    rc = 1;
    for (size_t i = 0; rc && i < size / sizeof(int); i++)
    {
        rc = fread(&num, sizeof(int), 1, f);
        if (rc == 1)
            printf("%d ", num);
        else
            return ERROR_READ_DATA;
    }
    fclose(f);

    return EXIT_SUCCESS;
}

int get_number_by_pos(FILE *f, int pos, int *num)
{
    int rc = EXIT_SUCCESS;
    if (fseek(f, pos * sizeof(int), SEEK_SET) == 0)
    {
        if (fread(num, sizeof(int), 1, f) != 1)
            rc = ERROR_READ_DATA;
    }
    else
        rc = ERROR_READ_DATA;
        
    return rc;
}

int put_number_by_pos(FILE *f, int pos, int num)
{
    int rc = EXIT_SUCCESS;
    if (fseek(f, pos * sizeof(int), SEEK_SET) == 0)
    {
        if (fwrite(&num, sizeof(int), 1, f) != 1)
            rc = ERROR_READ_DATA;
    }
    else
        rc = ERROR_READ_DATA;
        
    return rc;
}

int bubble_sort(FILE *f, size_t count_numbers)
{
    int num_1, num_2;
    for (size_t i = 0; i < count_numbers - 1; i++)
        for (size_t j = i + 1; j < count_numbers; j++)
        {
            if (get_number_by_pos(f, i, &num_1))
                return ERROR_READ_DATA;
            if (get_number_by_pos(f, j, &num_2))
                return ERROR_READ_DATA;
            if (num_1 > num_2)
            {
                if (put_number_by_pos(f, i, num_2))
                    return ERROR_WRITE_DATA;
                if (put_number_by_pos(f, j, num_1))
                    return ERROR_WRITE_DATA;
            }
        }
    
    return EXIT_SUCCESS;
}

int sort_bin(char *filename)
{
    FILE *f;
    f = fopen(filename, "r+b");
    if (f == NULL)
        return NOT_FOUND_FILE;
    size_t count_numbers = 0;
    int rc = file_size(f, &count_numbers);
    count_numbers /= sizeof(int);
    if (count_numbers == 0 || rc)
        return ERROR_EMPTY_FILE;
    rc = bubble_sort(f, count_numbers);
    fclose(f);
    
    return rc;
}
