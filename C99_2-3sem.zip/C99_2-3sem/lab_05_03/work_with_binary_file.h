#ifndef __WORK_WITH_BINARY_FILE__H__
#define __WORK_WITH_BINARY_FILE__H__

#include <stdio.h>

int modification(int count_arguments, char *str);
int create_bin(char *filename, const int count);
int file_size(FILE *f, size_t *size);
int output_bin(char *filename);
int get_number_by_pos(FILE *f, int pos, int *num);
int put_number_by_pos(FILE *f, int pos, int num);
int bubble_sort(FILE *f, size_t count_numbers);
int sort_bin(char *filename);

#endif
