#!/bin/bash

rm ./*.exe ./*.o ./*.c.gcov ./*.gcno ./*.gcda 2>/dev/null
cd ./func_tests/scripts/ || exit
rm ./f1_num.txt ./f2_num.txt ./neg_out.txt ./pos_out.txt 2>/dev/null
