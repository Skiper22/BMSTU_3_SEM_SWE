#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define ROW_SIZE 10
#define COLUMN_SIZE 10
#define EXPECTED_COUNT_SIZE 2
#define EXPECTED_COUNT_ELEMENT 1
#define MIN_SIZE 1
#define MAX_SIZE 10
#define MIN_VALUE 0
#define MAX_VALUE 10
#define YES 1
#define NO 0
#define RADIX 10

#define INPUT_ERR_SIZE 1
#define ERROR_INPUT_MATRIX 2
#define ERROR_INPUT_NUMBER 3
#define ERROR_EMPTY 4
#define ERR_VALUE_SIZE 3

int input_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; i++)
        for (size_t j = 0; j < column; j++)
            if (EXPECTED_COUNT_ELEMENT != scanf("%d", &matrix[i][j]))
                return ERROR_INPUT_MATRIX;
                
    return EXIT_SUCCESS;
}

void print_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; i++)
    {
        for (size_t j = 0; j < column; j++)
            printf("%d ", matrix[i][j]);
        printf("\n");
    }
}

int digit_in_number(int digit, int number)
{
    if (number < 0)
        number *= -1;
    if (number == digit)
        return YES;
    while (number > 0)
    {
        if (number % RADIX == digit)
            return YES;
        number /= RADIX;
    }
    return NO;
}

void delete_column(int matrix[ROW_SIZE][COLUMN_SIZE], int row, int column, int column_number)
{
    for (int i = 0; i < row; i++)
        for (int j = column_number; j < column - 1; j++)
            matrix[i][j] = matrix[i][j + 1];       
}

int number_is_digit(int number)
{
    if (number >= MAX_VALUE || number < MIN_VALUE)
        return EXIT_FAILURE;
    
    return EXIT_SUCCESS;
}

int get_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t *column, int number)
{       
    for (size_t i = 0; i < row; i++)
        for (size_t j = 0; j < *column; j++)
            if (digit_in_number(number, matrix[i][j]) == YES)
            {
                delete_column(matrix, row, *column, j);
                *column = *column - 1;
                j--;
            }
            
    if (*column == MIN_VALUE)
        return ERROR_EMPTY;
                     
    return EXIT_SUCCESS;
}

int input_matrix_size(size_t *row, size_t *column)
{
    printf("Input size of matrix: ");
    if (EXPECTED_COUNT_SIZE != scanf("%zu %zu", row, column))
       return INPUT_ERR_SIZE;
       
    if ((*row < MIN_SIZE || *row > MAX_SIZE) || (*column < MIN_SIZE || *column > MAX_SIZE))
        return ERR_VALUE_SIZE;
    
    return EXIT_SUCCESS;
}

int main(void)
{
    int matrix[ROW_SIZE][COLUMN_SIZE];
    size_t row, column;
    int rc = input_matrix_size(&row, &column);
    if (rc)
        return rc;
      
    if (input_matrix(matrix, row, column) == ERROR_INPUT_MATRIX)
        return ERROR_INPUT_MATRIX;
        
    int number;
    if (EXPECTED_COUNT_ELEMENT != scanf("%d", &number))
        return ERROR_INPUT_NUMBER;
    if (number_is_digit(number))
        return EXIT_FAILURE;
        
    if (get_matrix(matrix, row, &column, number) == ERROR_EMPTY)
        return ERROR_EMPTY;
        
    print_matrix(matrix, row, column);
        
    return EXIT_SUCCESS;
}
