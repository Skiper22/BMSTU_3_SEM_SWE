#ifndef _ARGUMENTS_H_

#define _ARGUMENTS_H_

int are_arguments_valid(int argc, char **argv);
int are_arguments_for_filter(int argc, char **argv);

#endif