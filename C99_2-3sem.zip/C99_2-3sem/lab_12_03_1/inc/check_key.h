#ifndef _CHECK_KEY_

#define _CHECK_KEY_

int check_key();

#endif