#ifndef _CHECK_MYSORT_

#define _CHECK_MYSORT_

int check_mysort();

#endif