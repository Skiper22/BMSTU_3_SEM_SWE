#include "constants.h"

int are_arguments_valid(int argc, char **argv)
{
    if (argc == 3 || (argc == 4 && argv[3][0] == 'f' && argv[3][1] == 0))
        return OK;
    
    return ERR_ARG;
}

int are_arguments_for_filter(int argc, char **argv)
{
    return (argc == 4 && argv[3][0] == 'f' && argv[3][1] == 0);
}
