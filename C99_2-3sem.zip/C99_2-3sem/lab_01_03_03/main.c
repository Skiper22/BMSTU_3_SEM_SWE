#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main()
{
    double velocity, time, accelaration;
    scanf("%lf %lf %lf", &velocity, &accelaration, &time);
    double distance = velocity * time + accelaration * time * time / 2;
    printf("%lf", distance);

    return EXIT_SUCCESS;
}
