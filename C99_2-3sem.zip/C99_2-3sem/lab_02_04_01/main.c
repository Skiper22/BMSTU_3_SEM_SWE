#include <stdio.h>
#include <stdlib.h>

#define ARRAY_COUNT_ELEM 10
#define EXIT_OVERFLOW 100

void output_array(int *array, int size)
{
    for (int i = 0; i < size; i++)
        printf("%d \n", array[i]);
}

void insertion_sort(int array[ARRAY_COUNT_ELEM], int array_size)
{
    for (int i = 0; i < array_size; i++)
    {
        int cur = array[i];
        int j = i - 1;
        while (j >= 0 && cur < array[j])
        {
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = cur;
    }
}

int input_array(int *array, int *size_array)
{
    int rc = 1;
    int input_count = 0;
    while (rc != 0 && input_count < ARRAY_COUNT_ELEM + 1)
    {
        rc = scanf("%d", &array[input_count]);
        if (rc == 1)
            input_count++;
    }
    int count_elem = input_count;
    if (input_count == ARRAY_COUNT_ELEM + 1)
        count_elem = ARRAY_COUNT_ELEM;
    if (input_count == 0)
        return EXIT_FAILURE;
    *size_array = count_elem;
    
    insertion_sort(array, count_elem);

    if (input_count == ARRAY_COUNT_ELEM + 1)
        return EXIT_OVERFLOW;
        
    return EXIT_SUCCESS;
}

int main()
{   
    int array[ARRAY_COUNT_ELEM + 1];
    int size_array;
    int result = input_array(array, &size_array);
    
    if (result == EXIT_FAILURE)
        return EXIT_FAILURE;
        
    output_array(array, size_array);
    
    if (result == EXIT_OVERFLOW)
        return EXIT_OVERFLOW;
    
    return EXIT_SUCCESS;
}
