#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define ROW_SIZE 10
#define COLUMN_SIZE 10
#define EXPECTED_COUNT_SIZE 2
#define EXPECTED_COUNT_ELEMENT 1
#define MIN_SIZE 1
#define MAX_SIZE 10
#define MIN_VALUE 0
#define MAX_VALUE 10
#define MAX_ARRAY_SIZE 100
#define EMPTY 0
#define RADIX 10

#define INPUT_ERR_SIZE 1
#define ERROR_INPUT_MATRIX 2
#define SMALL_SUM 3
#define ERR_VALUE_SIZE 4

int input_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; i++)
        for (size_t j = 0; j < column; j++)
            if (EXPECTED_COUNT_ELEMENT != scanf("%d", &matrix[i][j]))
                return ERROR_INPUT_MATRIX;
                
    return EXIT_SUCCESS;
}


void print_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; i++)
    {
        for (size_t j = 0; j < column; j++)
            printf("%d ", matrix[i][j]);
        printf("\n");
    }
}

int digit_sum(int number)
{
    int sum = 0;
    if (number < 0)
        number *= -1;
    while (number)
    {
        sum += number % RADIX;
        number /= RADIX;
    }
    if (sum > RADIX)
        return SMALL_SUM;
       
    return EXIT_SUCCESS;
}

void get_array(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column, int array[MAX_ARRAY_SIZE], size_t *array_size)
{
    size_t k = 0;
    for (size_t i = 0; i < row; i++)
        for (size_t j = 0; j < column; j++)
            if (digit_sum(matrix[i][j]))
            {
                array[k] = matrix[i][j];
                k++;
            }    
    *array_size = k;
}

void shift_3elem(int array[MAX_ARRAY_SIZE], size_t array_size)
{
    for (size_t i = 0; i < 3; i++)
    {
        int tmp = array[0];
        for (size_t j = 1; j < array_size; j++)
            array[j - 1] = array[j];
        array[array_size - 1] = tmp;
    }
}

void new_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], int array[MAX_ARRAY_SIZE], size_t row, size_t column)
{
    size_t k = 0;
    for (size_t i = 0; i < row; i++)
        for (size_t j = 0; j < column; j++)
        {
            if (digit_sum(matrix[i][j]))
            {
                matrix[i][j] = array[k];
                k++;
            }
        }
}

int input_matrix_size(size_t *row, size_t *column)
{
    printf("Input size of matrix: ");
    if (EXPECTED_COUNT_SIZE != scanf("%zu %zu", row, column))
       return INPUT_ERR_SIZE;
       
    if ((*row < MIN_SIZE || *row > MAX_SIZE) || (*column < MIN_SIZE || *column > MAX_SIZE))
        return ERR_VALUE_SIZE;
    
    return EXIT_SUCCESS;
}

int main(void)
{
    int matrix[ROW_SIZE][COLUMN_SIZE];
    int array[MAX_ARRAY_SIZE];
    size_t row, column;
    
    int rc = input_matrix_size(&row, &column);
    if (rc)
        return rc;
      
    if (input_matrix(matrix, row, column) == ERROR_INPUT_MATRIX)
        return ERROR_INPUT_MATRIX;
        
    size_t array_size = 0;    
    
    get_array(matrix, row, column, array, &array_size);
    if (array_size == EMPTY)
        return EXIT_FAILURE;
        
    shift_3elem(array, array_size);
    new_matrix(matrix, array, row, column);
    
    print_matrix(matrix, row, column);
        
    return EXIT_SUCCESS;
}
