#include <stdio.h>
#include <stdlib.h>


#define ZERO 0
#define EXPECTED_COUNT 2
void get_quotient_remainder(int dividend_2, int divisor_2)
{
    int quotient;
    for (quotient = 0 ; dividend_2 - divisor_2 >= 0 ; ++quotient)
        dividend_2 -= divisor_2;
    int remainder = dividend_2;
    printf("%d %d", quotient, remainder);
}

int main()
{
    int dividend, divisor;
    if (EXPECTED_COUNT != scanf("%d %d\n", &dividend, &divisor))
        return EXIT_FAILURE;   
    if (divisor <= ZERO || dividend <= ZERO)
        return EXIT_FAILURE;
    get_quotient_remainder(dividend, divisor);
    
    return EXIT_SUCCESS;
}


