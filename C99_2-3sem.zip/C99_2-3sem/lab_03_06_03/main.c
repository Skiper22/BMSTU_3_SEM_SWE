#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define ROW_SIZE 10
#define COLUMN_SIZE 10
#define EXPECTED_COUNT_SIZE 2
#define MIN_SIZE 1
#define MAX_SIZE 10

#define INPUT_ERR_SIZE 1
#define ERR_VALUE_SIZE 4

void matrix_filling(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    size_t elem = 1;
    for (size_t i = 0; i < row; i++) 
    {
        matrix[i][0] = elem;
        elem++;
    }
    
    for (size_t j = 1; j < column; j++)
    {
        matrix[row - 1][j] = elem;
        elem++;
    }
    
    for (int i = row - 2; i >= 0; i--) 
    {
        matrix[i][column - 1] = elem;
        elem++;
    }
    
    for (int j = column - 2; j >= 1; j--) 
    {
        matrix[0][j] = elem;
        elem++;
    }
 
        //Заполнение периметра
        //координаты ячейки, которую необходимо заполнить следующей.
    int c = 1;
    int d = 1;
    while (elem < row * column) 
    {
        //вниз.
        while (matrix[c + 1][d] == 0) 
        {
            matrix[c][d] = elem;
            elem++;
            c++;
        }
        //вправо.
        while (matrix[c][d + 1] == 0) 
        {
            matrix[c][d] = elem;
            elem++;
            d++;
        }
 
        //вверх.
        while (matrix[c - 1][d] == 0) 
        {
            matrix[c][d] = elem;
            elem++;
            c--;
        }
        //влево.
        while (matrix[c][d - 1] == 0) 
        {
            matrix[c][d] = elem;
            elem++;
            d--;
        }
    }
    // последний элемент в центре
    for (size_t i = 0; i < row; i++)
        for (size_t j = 0; j < column; j++)
            if (matrix[i][j] == 0)
                matrix[i][j] = elem;
}

void print_matrix(int matrix[ROW_SIZE][COLUMN_SIZE], size_t row, size_t column)
{
    for (size_t i = 0; i < row; i++)
    {
        for (size_t j = 0; j < column; j++)
            printf("%d ", matrix[i][j]);
        printf("\n");
    }
}

int input_matrix_size(size_t *row, size_t *column)
{
    printf("Input size of matrix: ");
    if (EXPECTED_COUNT_SIZE != scanf("%zu %zu", row, column))
       return INPUT_ERR_SIZE;
       
    if ((*row < MIN_SIZE || *row > MAX_SIZE) || (*column != *row))
        return ERR_VALUE_SIZE;
    
    return EXIT_SUCCESS;
}



int main(void)
{
    int matrix[ROW_SIZE][COLUMN_SIZE] = { 0 };
    size_t row, column;
    
    int rc = input_matrix_size(&row, &column);
    if (rc)
        return rc;
        
    matrix_filling(matrix, row, column);
    
    print_matrix(matrix, row, column);
        
    return EXIT_SUCCESS;
}
