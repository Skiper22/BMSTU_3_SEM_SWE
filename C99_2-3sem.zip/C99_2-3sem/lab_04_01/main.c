#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define RAISED 1

const char *my_strpbrk(const char *str, const char *sym)
{
    for (const char *str_1 = str; *str_1 != '\0'; ++str_1)
    {
        for (const char *str_2 = sym; *str_2 != '\0'; ++str_2)
            if (*str_1 == *str_2)
                return str_1;
    }
    
    return NULL;
} 

size_t my_strspn(const char *str, const char *sym)
{
    size_t count_elem = 0;
    for (const char *str_1 = str; *str_1 != '\0'; ++str_1)
    {
        short flag = 0;
        for (const char *str_2 = sym; *str_2 != '\0'; ++str_2)
            if (*str_1 == *str_2)
                flag = RAISED;
        if (flag != RAISED)
            return count_elem;
        ++count_elem;
    }
    
    return count_elem;
}

char *my_strchr(const char *str, int sym)
{
    const char *str_1 = str;

    for (; *str_1; ++str_1)
        if (*str_1 == sym)
            return (char *) str_1;
    if (*str_1 == sym)
        return (char *) str_1;
        
    return NULL;
}

size_t my_strcspn(const char *str, const char *sym)
{
    size_t count_elem = 0;
    for (const char *str_1 = str; *str_1 != '\0'; ++str_1)
        count_elem++;
    for (const char *str_2 = sym; *str_2 != '\0'; ++str_2)
    {
        size_t count_elem_before = 0;
        for (const char *str_1 = str; *str_1 != '\0'; ++str_1)
        {
            ++count_elem_before;
            if (*str_1 == *str_2)
                if (count_elem_before - 1 < count_elem)
                    count_elem = count_elem_before - 1;
        }
    }
    return count_elem;
}

char *my_strrchr(const char *str, int sym)
{
    const char *sym_position = NULL;
    const char *str_1 = str;
    for (; *str_1; ++str_1)
        if (*str_1 == sym)
            sym_position = str_1;
    if (*str_1 == sym)
        sym_position = str_1;
        
    return (char *) sym_position;
}

int main()
{
    int failure_count = 0;
    
    if (strpbrk("0123456789", "978") != my_strpbrk("0123456789", "978"))
        failure_count++;
    if (strpbrk("My name is Biba", "s") != my_strpbrk("My name is Biba", "s"))
        failure_count++;
      
    if (strspn("Gooood", "doo") != my_strspn("Gooood", "doo"))
        failure_count++;
    if (strspn("Hot dog", "took") != my_strspn("Hot dog", "took"))
        failure_count++;
    if (strspn("Steven Seagal", "Z") != my_strspn("Steven Seagal", "Z"))
        failure_count++;
      
    if (strcspn("Mike Tyson", "very") != my_strcspn("Mike Tyson", "very"))
        failure_count++;
    if (strcspn("Mike Tyson", "like") != my_strcspn("Mike Tyson", "like"))
        failure_count++;
    if (strcspn("Mike Tyson", "gym") != my_strcspn("Mike Tyson", "gym"))
        failure_count++;
 
    if (strchr("Donald Trump", 'u') != my_strchr("Donald Trump", 'u'))
        failure_count++;
    if (strchr("Donald Trump", 's') != my_strchr("Donald Trump", 's'))
        failure_count++;
    if (strchr("Donald Trump", 'a') != my_strchr("Donald Trump", 'a'))
        failure_count++;
   
    if (strcspn("Vladimir Putin", "is") != my_strcspn("Vladimir Putin", "is"))
        failure_count++;
    if (strcspn("Vladimir Putin", "the") != my_strcspn("Vladimir Putin", "the"))
        failure_count++;
    if (strcspn("Vladimir Putin", "best") != my_strcspn("Vladimir Putin", "best"))
        failure_count++;
   
    if (strrchr("Software engineering", 't') != my_strrchr("Software engineering", 't'))
        failure_count++;
    if (strrchr("Software engineering", 'o') != my_strrchr("Software engineering", 'o'))
        failure_count++;
    if (strrchr("Software engineering", 'p') != my_strrchr("Software engineering", 'p'))
        failure_count++;
        
    printf("%d \n", failure_count);   
    
    return EXIT_SUCCESS;
}
