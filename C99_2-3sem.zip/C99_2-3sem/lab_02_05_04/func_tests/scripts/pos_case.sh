#!/bin/bash

file_stream_in=$1
file_stream_out_expect=$2

touch pos_out.txt
file_app_args=()

if [ -v USE_VALGRIND ]; then #Проверка на то , поднят ли глобальный флаг USE_VALGRIND,если да, то все тестовые прогоны проводятся в оболочке valgrind, иначе — как обычно.
    if [ -n "$3" ]; then
        IFS=' ' read -r -a file_app_args <<< "$(cat "$3")"
    fi
    eval "valgrind --log-file=log.txt --quiet ./../../app.exe ${file_app_args[*]} < $file_stream_in > pos_out.txt"
    codv=$?
    if [ -s log.txt ]; then
    	val_cod="1" # файл непустой
    else
    	val_cod="0" # файл пустой
    fi
    
    if [ "$codv" != "0" ] && [ "$val_cod" == "1" ]; then
        exit 1
    elif [ "$codv" != "0" ] && [ "$val_cod" == "0" ]; then
        exit 2
    else
        ./comparator.sh pos_out.txt "$file_stream_out_expect"
        point=$?
    fi
    if [ "$point" != "1" ] && [ "$val_cod" == "0" ]; then
        exit 0
    elif [ "$point" != "1" ] && [ "$val_cod" == "1" ]; then
        exit 3
    elif [ "$point" == "1" ] && [ "$val_cod" == "1" ]; then
    	exit 1
    else
    	exit 2
    fi
else
    if [ -n "$3" ]; then
        IFS=' ' read -r -a file_app_args <<< "$(cat "$3")" 
    fi
    eval "./../../app.exe ${file_app_args[*]} < $file_stream_in > pos_out.txt"
    codv=$?
    if [ "$codv" != "0" ]; then
        exit 4
    else
        ./comparator.sh pos_out.txt "$file_stream_out_expect"
        point=$?
        if [ "$point" != "1" ]; then
            exit 5
        else
            exit 4
        fi
    fi
fi
