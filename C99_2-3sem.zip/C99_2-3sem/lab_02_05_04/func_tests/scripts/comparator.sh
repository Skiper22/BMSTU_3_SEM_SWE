#!/bin/bash

f1=$1
f2=$2

touch f1_num.txt f2_num.txt
grep -oE '[+-]?[0-9]+([.][0-9]+)?' "$f1" > f1_num.txt
grep -oE '[+-]?[0-9]+([.][0-9]+)?' "$f2" > f2_num.txt
if cmp f1_num.txt f2_num.txt; then
    exit 0 # equal
else
    exit 1 # not equal
fi
