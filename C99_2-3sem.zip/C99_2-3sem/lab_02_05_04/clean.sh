#!/bin/bash

rm ./app.exe ./main.o ./main.c.gcov ./main.gcno ./main.gcda 2>/dev/null
cd ./func_tests/scripts/ || exit
rm ./*.txt 2>/dev/null
