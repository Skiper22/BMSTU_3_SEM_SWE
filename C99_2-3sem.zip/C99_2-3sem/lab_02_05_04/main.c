#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define MIN_ARR_SIZE 1
#define ARR_SIZE 10
#define EXPECTED_COUNT_ELEM 1

int input_arr(int *pa, int *pb)
{
    int number;
    for (; pa < pb; ++pa)
    {
        if (scanf("%d", &number) != EXPECTED_COUNT_ELEM)
            return EXIT_FAILURE;
    
        *pa = number;
    }
    
    return EXIT_SUCCESS;
}

int find_count_uniq_elements(int *pa, int *pb)
{
    int result = 0;
    for (; pa < pb; pa++)
    {
        int flag = 0;
        for (int *pa1 = pa; pa1 < pb; pa1++)
        {
            if (*pa == *pa1)
                flag++;
        }
        if (flag == 1)
            result++;
    }

    return result;
}

int main()
{
    int mas[ARR_SIZE];
    int array_size;
    if (scanf("%d", &array_size) != EXPECTED_COUNT_ELEM) 
        return EXIT_FAILURE;
    if (array_size < MIN_ARR_SIZE || array_size > ARR_SIZE)
        return EXIT_FAILURE;
    int *pa = mas, *pb;
    pb = pa + array_size;
    if (input_arr(pa, pb) == EXIT_FAILURE)
        return EXIT_FAILURE;

    int uniq = find_count_uniq_elements(pa, pb);
    printf("%d", uniq);

    return EXIT_SUCCESS;
}

