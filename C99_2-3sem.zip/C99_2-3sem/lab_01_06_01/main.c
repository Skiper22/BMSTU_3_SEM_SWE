#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define EPS 1e-6
#define EXPECTED_COUNT 6

double find_triangle_area(int x1, int y1, int x2, int y2, int x3, int y3)
{
    return 0.5 * abs((x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1));
}

int main(void)
{
    int x1, y1, x2, y2, x3, y3;
    if (EXPECTED_COUNT != scanf("%d %d %d %d %d %d\n", &x1, &y1, &x2, &y2, &x3, &y3))
        return EXIT_FAILURE;
    
    double area = find_triangle_area(x1, y1, x2, y2, x3, y3);
    
    if (fabs(area) <= EPS)
        return EXIT_FAILURE;
    
    printf("%lf\n", area);
    
    return EXIT_SUCCESS;
}
