#!/bin/bash

rm ./main.exe ./main.o ./main.c.gcov ./main.gcno ./main.gcda
