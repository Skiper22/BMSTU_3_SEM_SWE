#!/bin/bash

if [ "$1" = "USE_VALGRIND" ]; then #Проверка на то , поднят ли глобальный флаг USE_VALGRIND,если да, то все тестовые прогоны проводятся в оболочке valgrind, иначе — как обычно.
    file_stream_in=$2
    file_stream_out_expect=$3
    touch pos_out.txt
    if [ -n "$4" ]; then
        file_app_args=$4
    else
        file_app_args=""
    fi
    valgrind --log-file=log.txt --quiet ./../../main.exe "$file_app_args" < "$file_stream_in" > pos_out.txt
    codv=$?
else
    file_stream_in=$1
    file_stream_out_expect=$2
    touch pos_out.txt
    if [ -n "$3" ]; then
        file_app_args=$3
    else
        file_app_args=""
    fi
    ./../../main.exe "$file_app_args" < "$file_stream_in" > pos_out.txt
    codv=$?
fi

if [ "$codv" != "0" ]; then
    exit 1
else
    ./comparator.sh pos_out.txt "$file_stream_out_expect"
    point=$?
    if [ "$point" != "0" ]; then
        exit 1
    else
        exit 0
    fi
fi

