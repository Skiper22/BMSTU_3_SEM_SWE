#include <stdio.h>
#include <math.h>
#include <stdlib.h>

double find_sum(double x, double eps)
{
    double s = 0;
    double num = x;
    for (int i = 1; fabs(num) >= eps; i += 2)
    {
        s += num;
        num *= x * x / (double)((i + 1) * (i + 2));
        num *= -1;
    }
    
    return s;
}

int main(void)
{
    double x, eps;
    int rc;
    rc = scanf("%lf %lf", &x, &eps);
    if (rc != 2 || eps <= 0 || eps >= 1)
        return EXIT_FAILURE;
 
    double s = find_sum(x, eps);
    double f = sin(x);
    double absolute_error = fabs(f - s);
    double relative_error = absolute_error / fabs(f);
    
    printf("%lf %lf %lf %lf\n", s, f, absolute_error, relative_error);

    return EXIT_SUCCESS;
}
