#include <stdio.h>
#include <stdlib.h>



int find_product(int number)
{
    int number_system = 10;
    int product = 1;
    while (number > 0)
    {
        product *= (number % number_system);
        number /= number_system;
    }

    return product;
}

int main()
{
    int num;
    scanf("%d", &num);
    num = abs(num);
    int res = find_product(num);
    printf("%d", res);

    return EXIT_SUCCESS;
}

