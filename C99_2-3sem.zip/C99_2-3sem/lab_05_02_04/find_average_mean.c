#include <stdlib.h>
#include "find_average_mean.h"
#include "defines.h"

int check_arguments(int count_arguments)
{
    if (count_arguments != EXPECTED_COUNT_ARGS)
        return INPUT_ERR;
        
    return EXIT_SUCCESS;
}

int file_exist(FILE *f)
{
    if (f == NULL)
        return ERROR_FIND_FILE;
       
    return EXIT_SUCCESS;
}

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

void get_average_mean(FILE *f, double *average_value, int max_pos, int min_pos)
{
    rewind(f);
    double sum = 0, num;
    if (max_pos < min_pos)
        swap(&max_pos, &min_pos);
    
    for (int i = 1; i < max_pos; i++)
    {
        fscanf(f, "%lf", &num);
        if (min_pos < i)
            sum += num;
    }
    *average_value = sum / (abs(max_pos - min_pos) - 1);
}

int find_max_min_pos(FILE *f, int *max_pos, int *min_pos)
{
    double max_num, min_num, num;
    fscanf(f, "%lf", &max_num);
    min_num = max_num;
    int index = 1;
    *max_pos = index;
    *min_pos = index;
    while (fscanf(f, "%lf", &num) == 1)
    {
        index++;
        if (num > max_num)
        {
            max_num = num;
            *max_pos = index;
        }
        if (num < min_num)
        {
            min_num = num;
            *min_pos = index;
        }
    }
    if (index < 2)
        return ERROR_DATA;
    if (abs(*max_pos - *min_pos) == 1)
        return EMPTY_SEQUENCE_BETWEEN_MAX_MIN;
        
    return SUCCESS;
}

