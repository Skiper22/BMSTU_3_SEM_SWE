#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "find_average_mean.h"
#include "defines.h"

int main(int argc, char **argv)
{
    double average_value = 0.0;
    int rc = EXIT_SUCCESS;
    rc = check_arguments(argc);
    if (rc)
        return rc;
    FILE *f;
    f = fopen(argv[1], "r");
    rc = file_exist(f);
    if (rc)
        return rc;
    int max_pos, min_pos;
    rc = find_max_min_pos(f, &max_pos, &min_pos);
    if (rc)
    {
        fclose(f);
        
        return rc;
    }
    get_average_mean(f, &average_value, max_pos, min_pos);
    fclose(f);
    printf("%lf\n", average_value);
        
    return rc;
}
