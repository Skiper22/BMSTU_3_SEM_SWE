#ifndef __FIND_AVERAGE_MEAN__H__
#define __FIND_AVERAGE_MEAN__H__

#include <stdio.h>

int check_arguments(int count_arguments);
int file_exist(FILE *f);
void get_average_mean(FILE *f, double *average_value, const int max_pos, const int min_pos);
int find_max_min_pos(FILE *f, int *max_pos, int *min_pos);
int process(int count_arguments, char **arguments_value, double *average_value);
void swap(int *x, int *y);

#endif
