#!/bin/bash

rm ./*.exe ./*.o ./*.c.gcov ./*.gcno ./*.gcda 2>/dev/null
cd ./func_tests/scripts/ || exit
rm ./*.txt 2>/dev/null
