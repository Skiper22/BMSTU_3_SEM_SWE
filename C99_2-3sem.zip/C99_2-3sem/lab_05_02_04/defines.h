#ifndef __DEFINES__H__
#define __DEFINES__H__

#define INPUT_ERR      1
#define ERROR_FIND_FILE 3
#define NOT_AVG_ERR    4
#define EPS            1e-8
#define ERROR_MAX_MIN 5
#define SUCCESS 0
#define EMPTY_SEQUENCE_BETWEEN_MAX_MIN 6
#define ERROR_DATA 10
#define EXPECTED_COUNT_ARGS 2

#endif
