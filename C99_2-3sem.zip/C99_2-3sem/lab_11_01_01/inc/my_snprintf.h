#ifndef MY_SNPRINTF_H_

#define MY_SNPRINTF_H_

int my_itoa(long long int number, char *str, int base);

int my_strlen(char *str);

void reverse_str(char *str);

void swap_char(char *left, char *right);

int my_itohex(unsigned int number, char **str);

void my_strncpy(char *dst, char *src, int n);
int my_snprintf(char *restrict s, size_t n, const char *restrict format, ...);

#endif
