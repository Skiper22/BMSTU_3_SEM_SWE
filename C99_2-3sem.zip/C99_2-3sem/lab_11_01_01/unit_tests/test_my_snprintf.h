#ifndef TEST_MY_SNPRINTF_H_

#define TEST_MY_SNPRINTF_H_

int activate_test_my_snprintf();

#endif

