#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "my_funcs.h"

#define MAX_LEN 27
#define MAX_SIZE 15
#define COUNT_ARGS 3
#define EXIT_SUCCESS 0

#define ERROR_ARGS       100
#define ERROR_FIND_FILE  101
#define ERROR_EMPTY_FILE 102
#define ERROR_DATA       103

int is_number(char str[])
{
    int flag = 1;
    for (size_t i = 0; i < strlen(str); i++)
        if (!isdigit(str[i]))
        {
            flag = 0;
            break;
        }
        
    return flag == 0 ? 0 : 1;
}

int check_args(const int argc, char *argv[])
{
    if (COUNT_ARGS != argc)
        return ERROR_ARGS;
    else if (!is_number(argv[2]) || atoi(argv[2]) <= 0)
        return ERROR_ARGS;

    return EXIT_SUCCESS;
}

int read_data(FILE *f, product_t arr[], int *amount_products)
{
    int count_products;
    int rc = fscanf(f, "%d\n", &count_products);
    if (rc != 1 || count_products < 1 || count_products > 15)
        return ERROR_DATA;
    for (int i = 0; i < count_products; i++)
    {
        if (fgets(arr[i].product_name, MAX_LEN, f) == NULL)
            return ERROR_DATA;
        if (fscanf(f, "%d\n", &arr[i].price) != 1)
            return ERROR_DATA;
        if (arr[i].price <= 0)
            return ERROR_DATA;
    }
    *amount_products = count_products;
    
    return EXIT_SUCCESS;
}

int file_exist(FILE *f)
{
    if (f == NULL)
        return ERROR_FIND_FILE;
    
    return EXIT_SUCCESS;
}

void print_products(product_t arr[], const int count_products, const int fix_price)
{
    for (int i = 0; i < count_products; i++)
        if (arr[i].price < fix_price)
        {
            printf("%s", arr[i].product_name);
            printf("%d\n", arr[i].price);
        }
}

