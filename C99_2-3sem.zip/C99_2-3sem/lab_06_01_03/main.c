#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "my_funcs.h"

#define MAX_LEN       27
#define MAX_SIZE      15
#define COUNT_ARGS     3

#define EXIT_SUCCESS 0


int main(int argc, char *argv[])
{
    FILE *f_in;
    product_t array[MAX_SIZE];
    int rc = check_args(argc, argv);
    if (rc != EXIT_SUCCESS)
        return rc;

    f_in = fopen(argv[1], "r");
    rc = file_exist(f_in);
    if (rc != EXIT_SUCCESS)
        return rc;

    int amount_products;
    
    rc = read_data(f_in, array, &amount_products);
    
    if (rc != EXIT_SUCCESS)
    {
        fclose(f_in);
        return rc;
    }
    
    print_products(array, amount_products, atoi(argv[2]));
    
    fclose(f_in);
                    
    return EXIT_SUCCESS;
}

