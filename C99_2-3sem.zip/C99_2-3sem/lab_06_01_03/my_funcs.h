#ifndef _MY_FUNCS_H_
#define _MY_FUNCS_H_

#define MAX_LEN   27
#define MAX_SIZE  15

typedef struct product_t
{
    char product_name[MAX_LEN];
    int price;
}product_t;

int is_number(char str[]);
int check_args(const int argc, char *argv[]);
int read_data(FILE *f, product_t arr[], int *amount_products);
int file_exist(FILE *f);
void print_products(product_t arr[], const int count_products, const int fix_price);

#endif
