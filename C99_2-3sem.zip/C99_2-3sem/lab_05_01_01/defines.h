#ifndef __DEFINES__H__
#define __DEFINES__H__

#define ERR_PARAMS 1
#define DATA_ERROR 2
#define NOT_FOUND_FIGURES 3
#define MIN_COUNT_NUM_SEQUENCE 2

#endif
