#include <stdlib.h>
#include "find_max1_max2_of_sequence.h"
#include "defines.h"

void swap(int *x, int *y)
{
    int temp = *x;
    *x = *y;
    *y = temp;
}

void find_max1_max2_sequence(FILE *f, int *max_1, int *max_2)
{
    int num;
    while (fscanf(f, "%d", &num) == 1)
    {
        if (num >= *max_1)
        {
            *max_2 = *max_1;
            *max_1 = num;
        }
        else if (num > *max_2)
            *max_2 = num;
    }         
}

int process(FILE *f, int *max_1, int *max_2)
{
    if (f == NULL)
        return ERR_PARAMS;
    
    int rc = fscanf(f, "%d %d", max_1, max_2);
    if (rc != MIN_COUNT_NUM_SEQUENCE)
        return DATA_ERROR;
    if (*max_1 <= *max_2)
        swap(max_1, max_2);
    find_max1_max2_sequence(f, max_1, max_2);
        
    return EXIT_SUCCESS;
}
