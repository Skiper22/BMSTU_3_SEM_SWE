#ifndef __FIND_MAX1_MAX2_OF_SEQUENCE__H__
#define __FIND_MAX1_MAX2_OF_SEQUENCE__H__

#include <stdio.h>

int process(FILE *f, int *max_1, int *max_2);
void swap(int *x, int *y);
void find_max1_max2_sequence(FILE *f, int *max_1, int *max_2);


#endif
