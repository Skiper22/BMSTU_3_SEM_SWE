#include <stdio.h>
#include <stdlib.h>
#include "find_max1_max2_of_sequence.h"
#include "defines.h"

int main(void)
{
    int max_1, max_2;
    int rc = process(stdin, &max_1, &max_2);
    if (rc)
        return rc;
    printf("%d %d", max_1, max_2);
    
    return rc;
}
