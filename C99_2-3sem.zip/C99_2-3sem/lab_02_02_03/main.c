#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <stdbool.h>


#define MAX_SIZE 10
#define MIN_COUNT_ELEMENT 0

int input_array(int *array, int count_elem_arr)
{
    for (int i = 0; i < count_elem_arr; i++)
        if (scanf("%d", array + i) != 1)
            return EXIT_FAILURE;
    return EXIT_SUCCESS;
}

void output_array(int *armstrong_array, int size)
{
    printf("Armstrong array: \n");
    for (int i = 0; i < size; i++)
        printf("%d \n", armstrong_array[i]);
}

int count_digits_of_number(int number)
{
    int count_digit;
    for (count_digit = 0; number != 0; number /= 10)
        count_digit++;
    return count_digit;
}
int armstrong_number(int number)
{
    int copy_number = number;
    int count_digit = count_digits_of_number(number);
    int sum = 0;
            
    for (sum = 0; copy_number != 0; copy_number /= 10)  
    {
        int digit = copy_number % 10;
        sum += pow(digit, count_digit);
    }
    if (sum != number)
        return EXIT_FAILURE;
        
    return EXIT_SUCCESS;
}

int get_armstrong_array(int *array, int count_elem_arr, int *armstrong_array, int *count_armstrong_elements)
{
    int index = 0;
    for (int i = 0; i < count_elem_arr; i++)
    {
        int number = array[i];
        if (number > 0)
            if (armstrong_number(number) == EXIT_SUCCESS)
            {
                armstrong_array[index] = number;
                index++;
            }
    }
    *count_armstrong_elements = index;
    if (index == 0)
        return EXIT_FAILURE;
        
    return EXIT_SUCCESS;
}

int main(void)
{
    int array[MAX_SIZE];
    int count_elem_arr;
    int armstrong_array[MAX_SIZE];
    printf("Enter number of array elements: ");
    if (scanf("%d", &count_elem_arr) != 1)
    {
        printf("Error value ");
        
        return EXIT_FAILURE;
    }
    
    if (count_elem_arr < MIN_COUNT_ELEMENT || count_elem_arr > MAX_SIZE)
        return EXIT_FAILURE;
        
    if (input_array(array, count_elem_arr))
        return EXIT_FAILURE;
    
    int count_armstrong_elements;
    if (get_armstrong_array(array, count_elem_arr, armstrong_array, &count_armstrong_elements))
        return EXIT_FAILURE;
        
    output_array(armstrong_array, count_armstrong_elements);
        
    return EXIT_SUCCESS;
}

